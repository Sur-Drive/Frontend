// import { useEffect, useRef } from 'react'
// import { useGoogleMaps } from '../../lib/googleMaps'
// import {
//   createHtmlMapOverlay,
//   type HtmlMapOverlayInstance,
// } from '../../lib/htmlMapOverlay'

// export interface MapMarkerSpec {
//   id: string
//   lat: number
//   lng: number
//   html: string
//   anchor?: [number, number]
//   onClick?: () => void
// }

// interface GoogleMapViewProps {
//   center: {
//     lat: number
//     lng: number
//   }

//   zoom: number

//   markers?: MapMarkerSpec[]

//   onMapClick?: (
//     lat: number,
//     lng: number
//   ) => void

//   onReady?: (
//     map: google.maps.Map
//   ) => void

//   className?: string

//   loadingFallback?: React.ReactNode

//   /**
//    * Compass bearing (0-360, 0 = north) to rotate the map to, e.g. from
//    * useRouteAnimation's `heading` while a trip is in progress. The
//    * standard Maps JS API only rotates 45°-imagery/vector tiles via
//    * map.setHeading, which most API keys/map IDs don't have enabled — so
//    * instead we rotate the whole map DOM with CSS (see the oversized
//    * wrapper below) to get a reliable "heading-up" navigation view
//    * regardless of map ID/tile type. Defaults to 0 (north-up).
//    */
//   heading?: number

//   /**
//    * When false, disables user pan/zoom/drag gestures on the map. Used
//    * while a trip is actively navigating and the camera is being driven
//    * programmatically every frame — letting the user drag against that at
//    * the same time is how you get map/gesture fights. Defaults to true.
//    */
//   interactive?: boolean

//   /**
//    * When true, `center` updates apply immediately via map.setCenter
//    * instead of the eased map.panTo. Use this while a parent is already
//    * supplying smoothly-interpolated positions every animation frame (e.g.
//    * useRouteAnimation) — panTo's own easing on top of that fights it and
//    * looks stuttery. Defaults to false (eased panTo), which is right for
//    * one-off center changes like "user tapped Use My Location".
//    */
//   followMode?: boolean
// }

// export default function GoogleMapView({
//   center,
//   zoom,
//   markers = [],
//   onMapClick,
//   onReady,
//   className,
//   loadingFallback,
//   heading = 0,
//   interactive = true,
//   followMode = false,
// }: GoogleMapViewProps) {
//   const { isLoaded, error } = useGoogleMaps()

//   const containerRef = useRef<HTMLDivElement>(null)

//   const mapRef = useRef<google.maps.Map | null>(null)

//   const overlaysRef = useRef<
//     Map<string, HtmlMapOverlayInstance>
//   >(new Map())

//   const hasCenteredRef = useRef(false)

//   const onMapClickRef = useRef(onMapClick)

//   onMapClickRef.current = onMapClick

//   useEffect(() => {
//     if (!isLoaded) return

//     if (!containerRef.current) return

//     if (mapRef.current) return

//     const map = new google.maps.Map(containerRef.current, {
//       center,
//       zoom,
//       disableDefaultUI: true,
//       zoomControl: false,
//       clickableIcons: false,
//       gestureHandling: interactive ? 'greedy' : 'none',
//       draggable: interactive,
//       disableDoubleClickZoom: !interactive,
//       keyboardShortcuts: interactive,
//       scrollwheel: interactive,
//     })

//     mapRef.current = map

//     hasCenteredRef.current = true

//     map.addListener('click', (e: google.maps.MapMouseEvent) => {
//       if (!e.latLng) return

//       onMapClickRef.current?.(
//         e.latLng.lat(),
//         e.latLng.lng()
//       )
//     })

//     onReady?.(map)

//     // eslint-disable-next-line react-hooks/exhaustive-deps
//   }, [isLoaded])

//   // Keep gesture/drag/zoom options in sync if `interactive` changes after
//   // the map's already been created (e.g. trip starts and we want to stop
//   // fighting the programmatic camera with user drags).
//   useEffect(() => {
//     const map = mapRef.current

//     if (!map) return

//     map.setOptions({
//       gestureHandling: interactive ? 'greedy' : 'none',
//       draggable: interactive,
//       disableDoubleClickZoom: !interactive,
//       keyboardShortcuts: interactive,
//       scrollwheel: interactive,
//     })
//   }, [interactive])

//   useEffect(() => {
//     const map = mapRef.current

//     if (!map) return

//     if (!hasCenteredRef.current) {
//       map.setCenter(center)
//       map.setZoom(zoom)

//       hasCenteredRef.current = true

//       return
//     }

//     // followMode (live trip tracking): a parent is already supplying
//     // smoothly-interpolated positions every animation frame, so snap the
//     // center directly — layering panTo's own easing on top makes it lag
//     // and stutter instead of tracking smoothly.
//     if (followMode) {
//       map.setCenter(center)
//     } else {
//       map.panTo(center)
//     }

//     if (map.getZoom() !== zoom) {
//       map.setZoom(zoom)
//     }

//     // eslint-disable-next-line react-hooks/exhaustive-deps
//   }, [center.lat, center.lng, zoom, followMode])

//   useEffect(() => {
//     const map = mapRef.current

//     if (!map) return

//     const existing = overlaysRef.current

//     const nextIds = new Set(
//       markers.map((m) => m.id)
//     )

//     existing.forEach((overlay, id) => {
//       if (!nextIds.has(id)) {
//         overlay.setMap(null)
//         existing.delete(id)
//       }
//     })

//     markers.forEach((marker) => {
//       const overlay = existing.get(marker.id)

//       if (!overlay) {
//         const next = createHtmlMapOverlay(
//           {
//             lat: marker.lat,
//             lng: marker.lng,
//           },
//           marker.html,
//           marker.anchor ?? [18, 18],
//           marker.onClick
//         )

//         next.setMap(map)

//         existing.set(marker.id, next)

//         return
//       }

//       overlay.updatePosition({
//         lat: marker.lat,
//         lng: marker.lng,
//       })

//       overlay.updateHtml(marker.html)
//     })
//   }, [markers])

//   useEffect(() => {
//     return () => {
//       overlaysRef.current.forEach((overlay) => {
//         overlay.setMap(null)
//       })

//       overlaysRef.current.clear()

//       mapRef.current = null
//     }
//   }, [])

//   return (
//     <div
//       className={className}
//       style={{
//         position: 'relative',
//         width: '100%',
//         height: '100%',
//       }}
//     >
//       {/*
//         Oversized (~142% = sqrt(2) of the viewport, so a corner is never
//         exposed at any rotation) wrapper that we CSS-rotate opposite the
//         current heading. It's centered over the visible area via the
//         negative inset, so at heading 0 nothing changes — the visible
//         region is exactly the same center/zoom as before. Everything
//         google.maps draws (tiles, our marker/route overlays, which live
//         inside this same DOM subtree) rotates together, so overlays stay
//         correctly pinned to their geo position while the whole view spins
//         to face the direction of travel, like Google/Waze turn-by-turn.
//       */}
//       <div
//         style={{
//           position: 'absolute',
//           inset: '-21%',
//           transform: `rotate(${-heading}deg)`,
//           transition: 'transform 0.25s linear',
//           willChange: 'transform',
//         }}
//       >
//         <div
//           ref={containerRef}
//           style={{
//             width: '100%',
//             height: '100%',
//           }}
//         />
//       </div>

//       {/* Fixed "you are here" heading-up puck: centered on screen and
//           always pointing straight up, since the map itself rotates
//           beneath it to match travel direction (exactly how Google Maps
//           nav mode renders the current-location arrow). Only shown while
//           actively following a heading so it doesn't appear on the plain
//           browsing map. */}
//       {followMode && (
//         <div
//           className="absolute z-10 pointer-events-none"
//           style={{ left: '50%', top: '50%', transform: 'translate(-50%, -50%)' }}
//         >
//           <div style={{ position: 'relative', width: 32, height: 32 }}>
//             <div
//               style={{
//                 position: 'absolute',
//                 inset: 0,
//                 borderRadius: '50%',
//                 background: '#0ea5e9',
//                 opacity: 0.25,
//               }}
//             />
//             <div
//               style={{
//                 position: 'absolute',
//                 inset: 3,
//                 borderRadius: '50%',
//                 background: '#0ea5e9',
//                 border: '2px solid white',
//                 boxShadow: '0 2px 8px rgba(0,0,0,0.35)',
//                 display: 'flex',
//                 alignItems: 'center',
//                 justifyContent: 'center',
//               }}
//             >
//               <svg viewBox="0 0 24 24" width={16} height={16} fill="white">
//                 <path d="M12 2L4.5 20.29l.71.71L12 18l6.79 3 .71-.71z" />
//               </svg>
//             </div>
//           </div>
//         </div>
//       )}

//       {!isLoaded && (
//         <div className="absolute inset-0 flex items-center justify-center bg-gray-100">
//           {loadingFallback ??
//             (error ? (
//               <p className="px-8 text-xs text-center text-red-500">
//                 {error}
//               </p>
//             ) : (
//               <div className="w-10 h-10 border-4 border-red-500 rounded-full animate-spin border-t-transparent" />
//             ))}
//         </div>
//       )}
//     </div>
//   )
// }



















import { useEffect, useRef } from 'react'
import { useGoogleMaps } from '../../lib/googleMaps'
import {
  createHtmlMapOverlay,
  type HtmlMapOverlayInstance,
} from '../../lib/htmlMapOverlay'

export interface MapMarkerSpec {
  id: string
  lat: number
  lng: number
  html: string
  anchor?: [number, number]
  onClick?: () => void
}

interface GoogleMapViewProps {
  center: {
    lat: number
    lng: number
  }
  zoom: number
  markers?: MapMarkerSpec[]
  /**
   * Fires on every map tap/click, including taps on one of Google's own
   * POI icons (restaurants, shops, etc. baked into the base map tiles —
   * distinct from our own HTML marker overlays above). When the tap
   * landed on a POI icon, `placeId` is populated so the caller can fetch
   * full place details for it; otherwise it's undefined and the caller
   * should treat it as a manual pin drop at (lat, lng).
   */
  onMapClick?: (lat: number, lng: number, placeId?: string) => void
  onReady?: (map: google.maps.Map) => void
  className?: string
  loadingFallback?: React.ReactNode
  heading?: number
  interactive?: boolean
  followMode?: boolean

  /**
   * Standard/Satellite/Terrain — passed straight through to
   * map.setMapTypeId. Defaults to 'roadmap' (the standard view).
   */
  mapTypeId?: 'roadmap' | 'satellite' | 'terrain' | 'hybrid'

  /**
   * Simulated 3D/tilted navigation view. The Maps JS API's real building
   * tilt only kicks in for vector maps with a Map ID (which this app
   * doesn't configure), so instead we fake the "tilted, looking ahead"
   * nav-app look with a CSS perspective/rotateX applied to the same
   * wrapper that already handles heading rotation below — 0 = flat
   * top-down (default), ~45 = tilted. Purely cosmetic, never affects
   * real lat/lng math.
   */
  tilt?: number

  /**
   * Live traffic layer (Google's own congestion tiles — green/orange/
   * red/dark-red road coloring, updated by Google in the background).
   * Toggled on/off by mounting or unmounting a google.maps.TrafficLayer;
   * no polling or extra requests on our side, Google's tiles refresh
   * themselves. Defaults to false.
   */
  showTraffic?: boolean

  /**
   * Diameter (px) of the fixed, screen-centered "you are here" puck shown
   * in followMode. Defaults to 32, which reads small against real road
   * width at typical navigation zoom — bump this (e.g. 44) for live
   * turn-by-turn.
   */
  puckSize?: number

  /**
   * Which glyph the followMode "you are here" puck draws — a directional
   * arrow for walking/cycling, or a top-down car for driving, mirroring
   * how Google Maps swaps its own live-position marker per travel mode.
   * Defaults to 'walking' (the arrow), so anything that doesn't pass
   * this keeps the original look.
   */
  puckMode?: 'driving' | 'walking' | 'cycling' | 'motorcycle'
}

export default function GoogleMapView({
  center,
  zoom,
  markers = [],
  onMapClick,
  onReady,
  className,
  loadingFallback,
  heading = 0,
  interactive = true,
  followMode = false,
  mapTypeId = 'roadmap',
  tilt = 0,
  showTraffic = false,
  puckSize = 32,
  puckMode = 'walking',
}: GoogleMapViewProps) {
  const { isLoaded, error } = useGoogleMaps()

  const containerRef = useRef<HTMLDivElement>(null)
  const mapRef = useRef<google.maps.Map | null>(null)
  const overlaysRef = useRef<Map<string, HtmlMapOverlayInstance>>(new Map())
  const hasCenteredRef = useRef(false)
  const onMapClickRef = useRef(onMapClick)

  onMapClickRef.current = onMapClick

  useEffect(() => {
    if (!isLoaded) return
    if (!containerRef.current) return
    if (mapRef.current) return

    const map = new google.maps.Map(containerRef.current, {
      center,
      zoom,
      mapTypeId,
      disableDefaultUI: true,
      zoomControl: false,
      mapTypeControl: false,
      fullscreenControl: false,
      streetViewControl: false,
      rotateControl: false,
      // Was false — turned on so tapping one of Google's baked-in POI
      // icons (a restaurant, shop, etc.) fires a click event carrying a
      // placeId, same as clicking a business on Google Maps itself. The
      // listener below calls e.stop() on those taps so Google's own
      // default info window never appears underneath our own sheet.
      clickableIcons: true,
      gestureHandling: interactive ? 'greedy' : 'none',
      draggable: interactive,
      disableDoubleClickZoom: !interactive,
      keyboardShortcuts: interactive,
      scrollwheel: interactive,
    })

    mapRef.current = map
    hasCenteredRef.current = true

    map.addListener(
      'click',
      (e: google.maps.MapMouseEvent | google.maps.IconMouseEvent) => {
        if (!e.latLng) return

        const placeId = (e as google.maps.IconMouseEvent).placeId
        if (placeId) {
          // Suppress Google's default POI info window — we show our own
          // PlaceDetailSheet for this instead.
          e.stop()
        }

        onMapClickRef.current?.(e.latLng.lat(), e.latLng.lng(), placeId)
      },
    )

    onReady?.(map)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isLoaded])

  useEffect(() => {
    const map = mapRef.current
    if (!map) return

    map.setOptions({
      gestureHandling: interactive ? 'greedy' : 'none',
      draggable: interactive,
      disableDoubleClickZoom: !interactive,
      keyboardShortcuts: interactive,
      scrollwheel: interactive,
    })
  }, [interactive])

  useEffect(() => {
    const map = mapRef.current
    if (!map) return

    if (!hasCenteredRef.current) {
      map.setCenter(center)
      hasCenteredRef.current = true
      return
    }

    if (followMode) {
      map.setCenter(center)
    } else {
      map.panTo(center)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [center.lat, center.lng, followMode])

  useEffect(() => {
    const map = mapRef.current
    if (!map) return
    if (!hasCenteredRef.current) return

    if (map.getZoom() !== zoom) {
      map.setZoom(zoom)
    }
  }, [zoom])

  useEffect(() => {
    const map = mapRef.current
    if (!map) return
    map.setMapTypeId(mapTypeId)
  }, [mapTypeId])

  // Live traffic layer — a plain google.maps.TrafficLayer bound/unbound
  // to the map. Google owns the tile refresh cadence entirely, so this
  // is just an on/off mount, not a data fetch we manage ourselves.
  const trafficLayerRef = useRef<google.maps.TrafficLayer | null>(null)

  useEffect(() => {
    const map = mapRef.current
    if (!map) return

    if (showTraffic) {
      if (!trafficLayerRef.current) {
        trafficLayerRef.current = new google.maps.TrafficLayer()
      }
      trafficLayerRef.current.setMap(map)
    } else {
      trafficLayerRef.current?.setMap(null)
    }
  }, [showTraffic, isLoaded])

  useEffect(() => {
    return () => {
      trafficLayerRef.current?.setMap(null)
      trafficLayerRef.current = null
    }
  }, [])

  // Best-effort: ask the native API for real 45° tilt too, in case this
  // location/zoom has imagery that supports it. Harmless no-op otherwise
  // — the CSS tilt below is what actually guarantees the visual on every
  // map/location.
  useEffect(() => {
    const map = mapRef.current
    if (!map) return
    try {
      map.setTilt(tilt)
    } catch {
      // setTilt can throw on some map configurations — ignore, CSS covers it
    }
  }, [tilt])

  useEffect(() => {
    const map = mapRef.current
    if (!map) return

    const existing = overlaysRef.current
    const nextIds = new Set(markers.map((m) => m.id))

    existing.forEach((overlay, id) => {
      if (!nextIds.has(id)) {
        overlay.setMap(null)
        existing.delete(id)
      }
    })

    markers.forEach((marker) => {
      const overlay = existing.get(marker.id)

      if (!overlay) {
        const next = createHtmlMapOverlay(
          { lat: marker.lat, lng: marker.lng },
          marker.html,
          marker.anchor ?? [18, 18],
          marker.onClick
        )
        next.setMap(map)
        existing.set(marker.id, next)
        return
      }

      overlay.updatePosition({ lat: marker.lat, lng: marker.lng })
      overlay.updateHtml(marker.html)
    })
  }, [markers])

  useEffect(() => {
    return () => {
      overlaysRef.current.forEach((overlay) => {
        overlay.setMap(null)
      })
      overlaysRef.current.clear()
      mapRef.current = null
    }
  }, [])

  return (
    <div
      className={className}
      style={{
        position: 'relative',
        width: '100%',
        height: '100%',
        overflow: 'hidden',
        perspective: tilt ? '900px' : undefined,
      }}
    >
      {/*
        Tilt wrapper: rotateX fakes the "looking ahead" nav-app tilt on
        top of a plain raster map (real building tilt needs a vector
        Map ID, which we don't configure). transform-origin at the
        bottom keeps the near edge anchored so tilting reads as leaning
        the horizon back, not sliding the whole view. The scale-up
        compensates for the extra empty space rotateX exposes at the
        top so the tilted view still fills the container.
      */}
      <div
        style={{
          position: 'absolute',
          inset: 0,
          transformStyle: 'preserve-3d',
          transform: tilt ? `rotateX(${tilt}deg) scale(1.35)` : undefined,
          transformOrigin: 'center bottom',
          transition: 'transform 0.3s ease',
        }}
      >
        <div
          style={{
            position: 'absolute',
            inset: '-21%',
            transform: `rotate(${-heading}deg)`,
            transition: 'transform 0.25s linear',
            willChange: 'transform',
          }}
        >
          <div ref={containerRef} style={{ width: '100%', height: '100%' }} />
        </div>
      </div>

      {followMode && (
        <div
          className="absolute z-10 pointer-events-none"
          style={{ left: '50%', top: '50%', transform: 'translate(-50%, -50%)' }}
        >
          <div style={{ position: 'relative', width: puckSize, height: puckSize }}>
            <div
              style={{
                position: 'absolute',
                inset: 0,
                borderRadius: '50%',
                background: '#0ea5e9',
                opacity: 0.25,
              }}
            />
            <div
              style={{
                position: 'absolute',
                inset: Math.round(puckSize * 0.09),
                borderRadius: '50%',
                background: '#0ea5e9',
                border: `${Math.max(2, Math.round(puckSize * 0.08))}px solid white`,
                boxShadow: '0 2px 8px rgba(0,0,0,0.35)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <svg viewBox="0 0 24 24" width={Math.round(puckSize * 0.5)} height={Math.round(puckSize * 0.5)} fill="white">
                {puckMode === 'driving' ? (
                  <>
                    <rect x="7" y="2.5" width="10" height="19" rx="3.2" />
                    <rect x="8.3" y="5.8" width="7.4" height="4" rx="1" fill="#0ea5e9" />
                    <rect x="8.3" y="13.2" width="7.4" height="4" rx="1" fill="#0ea5e9" />
                  </>
                ) : (
                  <path d="M12 2L4.5 20.29l.71.71L12 18l6.79 3 .71-.71z" />
                )}
              </svg>
            </div>
          </div>
        </div>
      )}

      {!isLoaded && (
        <div className="absolute inset-0 flex items-center justify-center bg-gray-100">
          {loadingFallback ??
            (error ? (
              <p className="px-8 text-xs text-center text-red-500">{error}</p>
            ) : (
              <div className="w-10 h-10 border-4 border-red-500 rounded-full animate-spin border-t-transparent" />
            ))}
        </div>
      )}
    </div>
  )
}