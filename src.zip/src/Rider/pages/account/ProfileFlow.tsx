import { useEffect, useState } from "react";
import {
  ChevronLeft,
  ChevronDown,
  Pencil,
  User,
  Phone,
  Mail,
  Cake,
  Check,
  X,
  CircleUserRound,
} from "lucide-react";
import DriverOtpEntry from "../../components/DriverOtpEntry";
import { useRideDriverProfile } from "../../hooks/useProfile";
import {
  useRequestEmailChange,
  useVerifyEmailChange,
  useResendEmailChange,
  useRequestPhoneChange,
  useVerifyPhoneChange,
  useResendPhoneChange,
} from "../../hooks/useAccount";

type Step =
  | "profile"
  | "change-email"
  | "change-email-otp"
  | "change-phone"
  | "change-phone-otp";

const GENDERS = ["Male", "Female", "Prefer not to say"] as const;

const MONTHS = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
];

// "1990-12-29" or "1990-12-29T00:00:00.000Z" -> "December 29, 1990"
function formatDob(raw: string): string {
  const m = raw.match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (!m) return raw;
  const month = MONTHS[Number(m[2]) - 1];
  return month ? `${month} ${Number(m[3])}, ${m[1]}` : raw;
}

// "0803 123 4567" / "803-123-4567" -> "+2348031234567" (API expects E.164).
function toE164(raw: string): string {
  const v = raw.replace(/[\s()-]/g, "");
  if (v.startsWith("+")) return v;
  if (v.startsWith("234")) return `+${v}`;
  if (v.startsWith("0")) return `+234${v.slice(1)}`;
  return `+234${v}`;
}

export default function ProfileFlow({ onBack }: { onBack: () => void }) {
  const [step, setStep] = useState<Step>("profile");
  const {
    data: profile,
    isLoading,
    error: profileError,
  } = useRideDriverProfile();
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [gender, setGender] = useState<(typeof GENDERS)[number]>("Male");
  const [dob, setDob] = useState("");
  const [genderOpen, setGenderOpen] = useState(false);

  const [pendingEmail, setPendingEmail] = useState("");
  const [pendingPhone, setPendingPhone] = useState("");
  const [toast, setToast] = useState(false);

  const requestEmail = useRequestEmailChange();
  const verifyEmail = useVerifyEmailChange();
  const resendEmail = useResendEmailChange();
  const requestPhone = useRequestPhoneChange();
  const verifyPhone = useVerifyPhoneChange();
  const resendPhone = useResendPhoneChange();

  // Fill the screen from GET /ride-drivers/profile.
  useEffect(() => {
    if (!profile) return;
    setName(profile.fullName);
    setPhone(profile.phone);
    setEmail(profile.email);
    setDob(profile.dateOfBirth ? formatDob(profile.dateOfBirth) : "");
    const match = GENDERS.find(
      (g) => g.toLowerCase() === profile.gender.toLowerCase(),
    );
    if (match) setGender(match);
  }, [profile]);

  const showSavedToast = () => {
    setToast(true);
    window.setTimeout(() => setToast(false), 3000);
  };

  /* ---------------- Change Email ---------------- */
  if (step === "change-email") {
    return (
      <ChangeContactStep
        title="Change Email"
        description={
          <>
            Your current email is {email}. To verify your new address, we'll
            send you a verification code. Please enter the code to complete
            verification
          </>
        }
        icon={<Mail size={16} className="text-[#6E43A3]" />}
        placeholder="Enter Your New Email"
        inputType="email"
        onBack={() => setStep("profile")}
        isSending={requestEmail.isPending}
        onSend={async (value) => {
          await requestEmail.mutateAsync({ newEmail: value });
          setPendingEmail(value);
          setStep("change-email-otp");
        }}
      />
    );
  }

  if (step === "change-email-otp") {
    return (
      <DriverOtpEntry
        destination={pendingEmail || email}
        onBack={() => setStep("change-email")}
        onVerify={async (otp) => {
          await verifyEmail.mutateAsync({ otp });
          setEmail(pendingEmail || email);
          setStep("profile");
          showSavedToast();
        }}
        onResend={async () => {
          await resendEmail.mutateAsync();
        }}
      />
    );
  }

  /* ---------------- Change Phone ---------------- */
  if (step === "change-phone") {
    return (
      <ChangeContactStep
        title="Change Phone Number"
        description={
          <>
            Your current Phone number is {phone}. To verify your new address,
            we'll send you a verification code. Please enter the code to complete
            verification
          </>
        }
        icon={<Phone size={16} className="text-[#6E43A3]" />}
        placeholder="Enter Your New Number"
        inputType="tel"
        onBack={() => setStep("profile")}
        isSending={requestPhone.isPending}
        onSend={async (value) => {
          await requestPhone.mutateAsync({
            newPhoneNumber: toE164(value),
          });
          setPendingPhone(value);
          setStep("change-phone-otp");
        }}
      />
    );
  }

  if (step === "change-phone-otp") {
    return (
      <DriverOtpEntry
        destination={pendingPhone || phone}
        onBack={() => setStep("change-phone")}
        onVerify={async (otp) => {
          await verifyPhone.mutateAsync({ otp });
          setPhone(pendingPhone || phone);
          setStep("profile");
          showSavedToast();
        }}
        onResend={async () => {
          await resendPhone.mutateAsync();
        }}
      />
    );
  }

  /* ---------------- Profile (root) ---------------- */
  return (
    <div className="relative flex flex-col w-full h-full min-h-0 bg-white font-outfit">
      <div className="flex-1 min-h-0 px-6 pt-4 pb-8 overflow-y-auto">
        <div className="w-full max-w-xl mx-auto">
          <button
            type="button"
            onClick={onBack}
            className="flex items-center justify-center rounded-full shadow-md h-11 w-11 bg-gray-50"
          >
            <ChevronLeft size={22} className="text-[#1F2937]" />
          </button>

          <h1 className="mt-6 text-xl sm:text-2xl font-bold text-[#1F2937]">Profile</h1>
          <p className="mt-1.5 text-sm sm:text-base text-[#9AA5B8]">
            Help our drivers identify you easily
          </p>
          {isLoading && (
            <p className="mt-3 text-sm text-[#9AA5B8]">
              Loading your profile...
            </p>
          )}
          {profileError && (
            <p className="mt-3 text-sm text-red-600">
              {profileError instanceof Error
                ? profileError.message
                : "Couldn't load your profile."}
            </p>
          )}

          {/* avatar */}
          <div className="flex justify-center mt-8">
            <div className="relative">
              <div className="flex h-32 w-32 items-center justify-center rounded-full bg-[#EFE6F7]">
                <CircleUserRound size={72} className="text-[#D8C3EC]" />
              </div>
              <button
                type="button"
                className="absolute bottom-1 right-1 flex h-10 w-10 items-center justify-center rounded-full bg-[#6E43A3] text-white shadow-md"
                aria-label="Edit photo"
              >
                <Pencil size={16} />
              </button>
            </div>
          </div>

          {/* name (read-only display) */}
          <div className="mt-8 flex items-center gap-3 rounded-2xl bg-[#F1F2F5] px-4 py-4">
            <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-[#E6DAF3]">
              <User size={16} className="text-[#6E43A3]" />
            </span>
            <span className="text-sm sm:text-base font-medium text-[#1F2937]">
              {name || "—"}
            </span>
          </div>

          {/* phone */}
          <div className="flex items-center justify-between mt-5 mb-2">
            <span className="text-sm text-[#1F2937]">Phone Number</span>
            <button
              type="button"
              onClick={() => setStep("change-phone")}
              className="text-sm font-semibold text-[#6E43A3]"
            >
              Change Number
            </button>
          </div>
          <div className="flex items-center gap-3 rounded-2xl bg-[#F1F2F5] px-4 py-4">
            <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-[#E6DAF3]">
              <Phone size={15} className="text-[#6E43A3]" />
            </span>
            <span className="text-sm sm:text-base font-medium text-[#1F2937]">
              {phone || "—"}
            </span>
          </div>

          {/* email */}
          <div className="flex items-center justify-between mt-5 mb-2">
            <span className="text-sm text-[#1F2937]">Email</span>
            <button
              type="button"
              onClick={() => setStep("change-email")}
              className="text-sm font-semibold text-[#6E43A3]"
            >
              Change Email
            </button>
          </div>
          <div className="flex items-center gap-3 rounded-2xl bg-[#F1F2F5] px-4 py-4">
            <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-[#E6DAF3]">
              <Mail size={15} className="text-[#6E43A3]" />
            </span>
            <span className="truncate text-sm sm:text-base font-medium text-[#1F2937]">
              {email || "—"}
            </span>
          </div>

          {/* gender */}
          <div className="relative mt-5">
            <button
              type="button"
              onClick={() => setGenderOpen((v) => !v)}
              className="flex w-full items-center gap-3 rounded-2xl bg-[#F1F2F5] px-4 py-4"
            >
              <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-[#E6DAF3]">
                <User size={15} className="text-[#6E43A3]" />
              </span>
              <span className="flex-1 text-left text-sm sm:text-base font-medium text-[#1F2937]">
                {gender}
              </span>
              <ChevronDown
                size={18}
                className={`text-[#4B5768] transition ${genderOpen ? "rotate-180" : ""}`}
              />
            </button>
            {genderOpen && (
              <div className="absolute inset-x-0 top-full z-10 mt-1.5 overflow-hidden rounded-2xl bg-white shadow-lg ring-1 ring-black/5">
                {GENDERS.map((g) => (
                  <button
                    key={g}
                    type="button"
                    onClick={() => {
                      setGender(g);
                      setGenderOpen(false);
                    }}
                    className="flex w-full items-center justify-between px-4 py-3 text-left text-sm sm:text-base text-[#1F2937] hover:bg-gray-50"
                  >
                    {g}
                    {gender === g && (
                      <Check size={16} className="text-[#6E43A3]" />
                    )}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* dob */}
          <div className="mt-5 flex items-center gap-3 rounded-2xl bg-[#F1F2F5] px-4 py-4">
            <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-[#E6DAF3]">
              <Cake size={15} className="text-[#6E43A3]" />
            </span>
            <span className="text-sm sm:text-base font-medium text-[#1F2937]">
              {dob || "—"}
            </span>
          </div>

          <button
            type="button"
            onClick={showSavedToast}
            className="mt-8 w-full rounded-full bg-[#6E43A3] py-4 text-sm sm:text-base font-bold text-white shadow-sm transition active:scale-[0.99]"
          >
            Save Changes
          </button>
        </div>
      </div>

      {toast && (
        <div className="pointer-events-none absolute inset-x-0 bottom-[calc(env(safe-area-inset-bottom,0px)+16px)] flex justify-center px-6">
          <div className="pointer-events-auto flex w-full max-w-xl items-center gap-3 rounded-2xl bg-white px-4 py-3.5 shadow-[0_8px_24px_rgba(0,0,0,0.15)]">
            <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-[#DCF5E4]">
              <Check size={13} className="text-[#1E9E56]" strokeWidth={3} />
            </span>
            <span className="flex-1 text-xs sm:text-sm font-medium text-[#1F2937]">
              Changes successfully saved
            </span>
            <button
              type="button"
              onClick={() => setToast(false)}
              className="shrink-0 text-[#9AA5B8]"
              aria-label="Dismiss"
            >
              <X size={16} />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Shared "enter new value, send code" step for email/phone changes   */
/* ------------------------------------------------------------------ */

function ChangeContactStep({
  title,
  description,
  icon,
  placeholder,
  inputType,
  onBack,
  onSend,
  isSending,
}: {
  title: string;
  description: React.ReactNode;
  icon: React.ReactNode;
  placeholder: string;
  inputType: "email" | "tel";
  onBack: () => void;
  /** Throw to show the error under the input. */
  onSend: (value: string) => Promise<void>;
  isSending: boolean;
}) {
  const [value, setValue] = useState("");
  const [error, setError] = useState("");

  const send = async () => {
    if (!value.trim() || isSending) return;
    setError("");
    try {
      await onSend(value.trim());
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : "Couldn't send the code. Please try again.",
      );
    }
  };

  return (
    <div className="flex flex-col w-full h-full min-h-0 bg-white font-outfit">
      <div className="flex-1 min-h-0 px-6 pt-4 pb-8 overflow-y-auto">
        <div className="w-full max-w-xl mx-auto">
          <button
            type="button"
            onClick={onBack}
            className="flex items-center justify-center rounded-full shadow-md h-11 w-11 bg-gray-50"
          >
            <ChevronLeft size={22} className="text-[#1F2937]" />
          </button>

          <h1 className="mt-6 text-xl sm:text-2xl font-bold text-[#1F2937]">{title}</h1>
          <p className="mt-2 text-sm sm:text-base leading-relaxed text-[#9AA5B8]">
            {description}
          </p>

          <div className="mt-6 flex items-center gap-3 rounded-2xl bg-[#F1F2F5] px-4 py-4">
            <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-[#E6DAF3]">
              {icon}
            </span>
            <input
              type={inputType}
              value={value}
              onChange={(e) => {
                setValue(e.target.value);
                setError("");
              }}
              onKeyDown={(e) => e.key === "Enter" && void send()}
              placeholder={placeholder}
              className="w-full flex-1 bg-transparent text-base font-medium text-[#1F2937] placeholder:text-[#9AA5B8] focus:outline-none"
            />
          </div>

          {error && <p className="mt-2 text-sm text-red-500">{error}</p>}

          <button
            type="button"
            disabled={!value.trim() || isSending}
            onClick={() => void send()}
            className={`mt-5 w-full rounded-full py-4 text-sm sm:text-base font-bold text-white shadow-sm transition active:scale-[0.99] ${
              value.trim() ? "bg-[#6E43A3]" : "bg-[#C9B6DE]"
            }`}
          >
            {isSending ? "Sending..." : "Send Code"}
          </button>
        </div>
      </div>
    </div>
  );
}
