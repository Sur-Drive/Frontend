import { useEffect, useState } from "react";
import { ChevronLeft, Delete } from "lucide-react";
import { useLocation, useNavigate } from "react-router-dom";
import { useVerifyRideDriverOtp } from "../hooks/useAuth";

const OTP_LENGTH = 5;
const COUNTDOWN_SECONDS = 45;

interface OtpLocationState {
  identifier?: string;
  role?: string;
  userId?: string;
}

export default function OtpPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const state = (location.state as OtpLocationState) || {};

  const identifier = state.identifier ?? "";
  const role = state.role ?? "driver";
  const userId = state.userId ?? "";

  const [code, setCode] = useState<string[]>(new Array(OTP_LENGTH).fill(""));
  const [timer, setTimer] = useState(COUNTDOWN_SECONDS);
  const [canResend, setCanResend] = useState(false);
  const [error, setError] = useState("");
  const [isResending, setIsResending] = useState(false);
  const { mutate: verifyOtp, isPending: isVerifying } =
    useVerifyRideDriverOtp();

  // No identifier to verify (e.g. page opened directly) — send back to register.
  useEffect(() => {
    if (!identifier || !userId) {
      navigate("/register", { replace: true });
    }
  }, [identifier, userId, navigate]);

  useEffect(() => {
    if (timer <= 0) {
      setCanResend(true);
      return;
    }
    const interval = setInterval(() => {
      setTimer((prev) => {
        if (prev <= 1) {
          setCanResend(true);
          clearInterval(interval);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [timer]);

  const activeIndex = code.findIndex((d) => d === "");
  const currentIndex = activeIndex === -1 ? OTP_LENGTH - 1 : activeIndex;

  // Verify the OTP against the backend.
  const submitCode = (fullCode: string) => {
    verifyOtp(
      { userId, otp: fullCode },
      {
        onSuccess: (data) => {
          if (data.tempToken) {
            localStorage.setItem("driverOnboardingToken", data.tempToken);
          }
          navigate("/register/personal-information", {
            replace: true,
            state: { identifier, role, userId },
          });
        },
        onError: (err: unknown) => {
          setError(err instanceof Error ? err.message : "Invalid OTP.");
          setCode(new Array(OTP_LENGTH).fill(""));
        },
      },
    );
  };

  const handleDigit = (digit: string) => {
    if (isVerifying) return;
    if (activeIndex === -1) return;
    setError("");
    const next = [...code];
    next[activeIndex] = digit;
    setCode(next);

    if (activeIndex === OTP_LENGTH - 1) {
      const fullCode = next.join("");
      if (fullCode.length === OTP_LENGTH) submitCode(fullCode);
    }
  };

  const handleBackspace = () => {
    if (isVerifying) return;
    const lastFilled = [...code].reverse().findIndex((d) => d !== "");
    if (lastFilled === -1) return;
    const indexToClear = OTP_LENGTH - 1 - lastFilled;
    const next = [...code];
    next[indexToClear] = "";
    setCode(next);
    setError("");
  };

  // No API for now: just reset the timer and clear the boxes.
  const handleResend = () => {
    if (!canResend) return;
    setIsResending(true);
    setTimeout(() => {
      setIsResending(false);
      setTimer(COUNTDOWN_SECONDS);
      setCanResend(false);
      setCode(new Array(OTP_LENGTH).fill(""));
      setError("");
    }, 400);
  };

  const keypadRows: Array<Array<string | null>> = [
    ["1", "2", "3"],
    ["4", "5", "6"],
    ["7", "8", "9"],
    [null, "0", "backspace"],
  ];

  return (
    <div className="font-outfit relative flex min-h-[100dvh] flex-col bg-white">
      <div className="flex-1 px-6 pt-4 pb-4">
        <button
          onClick={() => navigate(-1)}
          aria-label="Back"
          className="flex items-center justify-center bg-white rounded-full shadow-md h-11 w-11"
        >
          <ChevronLeft size={22} />
        </button>

        <h1 className="mt-8 text-[28px] font-bold text-[#2b2b2b]">
          OTP Verification
        </h1>
        <p className="mt-2 text-base text-gray-400">
          Enter the OTP sent to{" "}
          <span className="font-semibold text-gray-800">{identifier}</span>
        </p>

        {/* OTP boxes */}
        <div className="flex items-center gap-4 mt-8">
          {code.map((digit, i) => (
            <div
              key={i}
              className={`flex h-[68px] w-[68px] items-center justify-center rounded-2xl text-2xl font-bold text-gray-800 transition ${
                digit
                  ? "bg-white shadow-[0_6px_16px_rgba(0,0,0,0.12)]"
                  : i === currentIndex
                    ? "bg-white shadow-[0_6px_16px_rgba(0,0,0,0.12)]"
                    : "bg-[#f5f5f4]"
              }`}
            >
              {digit}
            </div>
          ))}
        </div>

        <button
          onClick={handleResend}
          disabled={!canResend || isResending}
          className={`mt-8 h-14 w-full rounded-2xl text-lg font-semibold transition ${
            canResend && !isResending
              ? "bg-[#6E43A3] text-white shadow-lg shadow-[#6E43A3]/30 active:scale-[0.99]"
              : "cursor-not-allowed bg-[#dcdcdc] text-white/90"
          }`}
        >
          {canResend
            ? isResending
              ? "Sending..."
              : "Resend OTP"
            : `Resend OTP (${timer})`}
        </button>

        <button
          onClick={() => navigate(-1)}
          className="mt-6 block w-full text-center text-base font-semibold text-[#d4a418]"
        >
          Change Email
        </button>

        {error && (
          <p className="mt-4 text-sm text-center text-red-600">{error}</p>
        )}
      </div>

      {/* Custom numeric keypad */}
      <div className="mt-auto bg-[#dedee6] px-4 pb-6 pt-4">
        <div className="flex flex-col gap-3">
          {keypadRows.map((row, ri) => (
            <div key={ri} className="flex gap-3">
              {row.map((key, ki) => {
                if (key === null) {
                  return <div key={ki} className="flex-1 h-16" />;
                }
                if (key === "backspace") {
                  return (
                    <button
                      key={ki}
                      type="button"
                      onClick={handleBackspace}
                      aria-label="Delete"
                      className="flex h-16 flex-1 items-center justify-center rounded-2xl bg-white text-gray-800 shadow-sm active:scale-[0.97]"
                    >
                      <Delete size={22} />
                    </button>
                  );
                }
                return (
                  <button
                    key={ki}
                    type="button"
                    onClick={() => handleDigit(key)}
                    className="h-16 flex-1 rounded-2xl bg-white text-xl font-semibold text-gray-800 shadow-sm active:scale-[0.97]"
                  >
                    {key}
                  </button>
                );
              })}
            </div>
          ))}
        </div>
      </div>

      {/* Verifying overlay */}
      {isVerifying && (
        <div className="absolute inset-0 z-10 flex items-center justify-center bg-white/30 backdrop-blur-[1px] backdrop-grayscale">
          <div className="h-10 w-10 animate-spin rounded-full border-4 border-gray-200 border-t-[#6E43A3]" />
        </div>
      )}
    </div>
  );
}
