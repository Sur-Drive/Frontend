const API_BASE = "https://backend-production-01de.up.railway.app";

async function parseResponse(res: Response, fallbackMessage: string) {
  const responseText = await res.text();

  if (!res.ok) {
    let errorData: any = {};
    try {
      errorData = JSON.parse(responseText);
    } catch {
      errorData = { raw: responseText };
    }
    throw new Error(
      errorData.message ||
        errorData.error ||
        `${fallbackMessage} (${res.status})`,
    );
  }

  return responseText ? JSON.parse(responseText) : {};
}

export interface RideDriverSendOtpPayload {
  email: string;
  phoneNumber: string;
  location: string;
}

export interface RideDriverSendOtpResponse {
  message: string;
  userId?: string;
  [key: string]: any;
}

export async function sendRideDriverOtp(
  payload: RideDriverSendOtpPayload,
): Promise<RideDriverSendOtpResponse> {
  const res = await fetch(`${API_BASE}/ride-drivers/send-otp`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Accept: "application/json" },
    body: JSON.stringify(payload),
  });

  return parseResponse(res, "Failed to send OTP");
}

export interface RideDriverVerifyOtpPayload {
  userId: string;
  otp: string;
}

export interface RideDriverVerifyOtpResponse {
  message?: string;
  tempToken?: string;
  step?: string;
  nextStep?: string;
  completed?: boolean;
  progress?: number;
  totalSteps?: number;
  [key: string]: any;
}

export async function verifyRideDriverOtp(
  payload: RideDriverVerifyOtpPayload,
): Promise<RideDriverVerifyOtpResponse> {
  const res = await fetch(`${API_BASE}/ride-drivers/verify-otp`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Accept: "application/json" },
    body: JSON.stringify(payload),
  });

  return parseResponse(res, "Failed to verify OTP");
}

export interface RideDriverPersonalInfoPayload {
  firstName: string;
  lastName: string;
  gender: string;
  dateOfBirth: string; // YYYY-MM-DD
  nin: string;
}

export interface RideDriverPersonalInfoResponse {
  message?: string;
  tempToken?: string;
  step?: string;
  nextStep?: string;
  completed?: boolean;
  progress?: number;
  totalSteps?: number;
  [key: string]: any;
}

export async function submitRideDriverPersonalInfo(
  payload: RideDriverPersonalInfoPayload,
): Promise<RideDriverPersonalInfoResponse> {
  const token = localStorage.getItem("driverOnboardingToken");
  const res = await fetch(`${API_BASE}/ride-drivers/personal`, {
    method: "PATCH",
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: JSON.stringify(payload),
  });

  return parseResponse(res, "Failed to save personal information");
}

export interface RideDriverLoginPayload {
  identifier: string; // email or phone number
  password: string;
}

export interface RideDriverLoginResponse {
  message: string;
  token?: string;
  accessToken?: string;
  user?: any;
  [key: string]: any;
}

export async function loginRideDriver(
  payload: RideDriverLoginPayload,
): Promise<RideDriverLoginResponse> {
  const res = await fetch(`${API_BASE}/ride-drivers/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Accept: "application/json" },
    body: JSON.stringify(payload),
  });

  return parseResponse(res, "Failed to sign in");
}

// ---------------------------------------------------------------------------
// Forgot password
// ---------------------------------------------------------------------------

export interface RideDriverForgotPasswordPayload {
  email: string;
}

export interface RideDriverForgotPasswordResponse {
  message?: string;
  [key: string]: any;
}

/** POST /ride-drivers/forgot-password — emails a 5-digit OTP to the driver. */
export async function forgotRideDriverPassword(
  payload: RideDriverForgotPasswordPayload,
): Promise<RideDriverForgotPasswordResponse> {
  const res = await fetch(`${API_BASE}/ride-drivers/forgot-password`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Accept: "application/json" },
    body: JSON.stringify(payload),
  });

  return parseResponse(res, "Failed to send verification code");
}

export interface RideDriverForgotPasswordVerifyOtpPayload {
  email: string;
  otp: string;
}

export interface RideDriverForgotPasswordVerifyOtpResponse {
  message?: string;
  resetToken?: string;
  tempToken?: string;
  token?: string;
  [key: string]: any;
}

/** POST /ride-drivers/forgot-password/verify-otp — checks the emailed OTP. */
export async function verifyRideDriverForgotPasswordOtp(
  payload: RideDriverForgotPasswordVerifyOtpPayload,
): Promise<RideDriverForgotPasswordVerifyOtpResponse> {
  const res = await fetch(
    `${API_BASE}/ride-drivers/forgot-password/verify-otp`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify(payload),
    },
  );

  return parseResponse(res, "Failed to verify code");
}

export interface RideDriverResetPasswordPayload {
  newPassword: string;
  confirmPassword: string;
}

/**
 * POST /ride-drivers/reset-password — final step of forgot-password.
 * The body has no email/otp, so identity comes from the token returned by
 * /forgot-password/verify-otp, sent as a Bearer token.
 */
export async function resetRideDriverPassword(
  payload: RideDriverResetPasswordPayload & { resetToken?: string },
): Promise<{ message?: string; [key: string]: any }> {
  const { resetToken, ...body } = payload;
  const res = await fetch(`${API_BASE}/ride-drivers/reset-password`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
      ...(resetToken ? { Authorization: `Bearer ${resetToken}` } : {}),
    },
    body: JSON.stringify(body),
  });

  return parseResponse(res, "Failed to reset password");
}
