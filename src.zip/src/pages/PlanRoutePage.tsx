import { useState, useRef, useEffect, useCallback, useMemo } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { recordVisitedPlace } from "../lib/placeHistory";
import { useQuery } from "@tanstack/react-query";
import LazyGoogleMap from "../components/map/LazyGoogleMap";
import RouteMapView from "../components/map/RouteMapView";
import type { MapMarkerSpec } from "../components/map/GoogleMapView";
import MapControls, { type MapTypeId } from "../components/map/MapControls";
import StreetViewModal, {
  StreetViewPegman,
} from "../components/map/StreetView";
import AddressAutocompleteInput, {
  type SelectedAddress,
} from "../components/map/AddressAutocompleteInput";
import {
  reportPinHtml,
  getReportPinAnchor,
  userLocationPinHtml,
  USER_LOCATION_ANCHOR,
  destinationPinHtml,
  DESTINATION_PIN_ANCHOR,
  startPinHtml,
  START_PIN_ANCHOR,
} from "../components/map/mapMarkerIcons";
import BottomNav from "../components/BottomNav";
import AuthFlow from "../components/AuthFlow";
import NotificationsPanel from "../components/NotificationsPanel";
import {
  useNotificationsList,
  useUnreadCount,
  useMarkAllRead,
  useMarkNotificationRead,
} from "../hooks/useNotifications";
import { useFleetOwnerGate } from "../hooks/useFleetOwnerGate";
import { getUserProfile } from "../api/profile";
import { reverseGeocode } from "../api/geocoding";
import { usePlanRouteOptions } from "../hooks/useRoutePlan";
import {
  pickDefaultMode,
  getRoutePath,
  getRouteAlternatives,
} from "../api/route";
import type {
  RouteModeKey,
  RouteOption,
  RouteAlternative,
} from "../types/routePlan";
import { useRouteAnimation } from "../hooks/useRouteAnimation";
import { useTriggerSos, useCancelSos } from "../hooks/useSos";
import { ApiError } from "../lib/apiClient";
import {
  cumulativeDistances,
  pointAtFraction,
  projectPointOntoPath,
  haversineMeters,
  type LatLng,
} from "../lib/geoPath";
import { useMultilingualVoiceGuidance } from "../hooks/useMultilingualVoiceGuidance";
import {
  resolveManeuverPhrase,
  resolveHazardPhrase,
} from "../lib/multilingualPhrases";
import { useTurnByTurn } from "../hooks/useTurnByTurn";
import { useWakeWord, useVoiceSearch } from "../hooks/useVoiceSearch";
import { forwardGeocode } from "../api/geocoding";
import { Mic, MapPinned } from "lucide-react";
import TurnByTurnCard, {
  describeManeuver,
} from "../components/map/TurnByTurnCard";
import VoiceGuidanceControl from "../components/map/VoiceGuidanceControl";
import { formatManeuverDistance } from "../lib/maneuvers";
import { useCollisionGuard } from "../hooks/useCollisionGuard";
import CollisionGuardView from "../components/map/CollisionGuardView";
import { describeWarning } from "../lib/collisionDetection";
import { getIpLocation } from "../lib/ipLocation";

// ─── Types ─────────────────────────────────────────────
type ReportType =
  | "wave"
  | "hill"
  | "pothole"
  | "hazard"
  | "sos"
  | "sign"
  | "warning"
  | "tractor";

interface Report {
  id: string;
  lat: number;
  lng: number;
  color: string;
  type: ReportType;
  label: string;
}

interface HazardLike {
  type?: string;
  description?: string;
  distanceLabel?: string;
  location?: { address?: string };
}

const HAZARD_ICON: Record<string, string> = {
  POTHOLE: "🕳️",
  FLOOD: "🌊",
  ACCIDENT: "⚠️",
  DEBRIS: "🪨",
  ROAD_WORKS: "🚜",
  CHECKPOINT: "🚧",
  DANGER: "⚠️",
  SOS: "🆘",
};

const HAZARD_LABEL: Record<string, string> = {
  POTHOLE: "Pothole ahead",
  FLOOD: "Flood risk ahead",
  ACCIDENT: "Accident reported ahead",
  DEBRIS: "Debris in the road ahead",
  ROAD_WORKS: "Road works ahead",
  CHECKPOINT: "Checkpoint ahead",
  DANGER: "Hazard ahead",
  SOS: "Emergency reported ahead",
};

function describeUpcomingHazard(hazards: unknown[] | undefined) {
  const first = hazards?.[0] as HazardLike | undefined;
  if (!first) return null;

  const type =
    typeof first.type === "string" ? first.type.toUpperCase() : undefined;
  return {
    icon: (type && HAZARD_ICON[type]) || "⚠️",
    label:
      (type && HAZARD_LABEL[type]) ||
      first.description ||
      first.location?.address ||
      "Hazard ahead",
  };
}

// ─── Data ──────────────────────────────────────────────
const reports: Report[] = [
  {
    id: "r1",
    lat: 6.5244,
    lng: 3.3792,
    color: "#3b82f6",
    type: "wave",
    label: "Chesapeake Avenue",
  },
  {
    id: "r2",
    lat: 6.535,
    lng: 3.368,
    color: "#f59e0b",
    type: "hill",
    label: "Southwood Avenue",
  },
  {
    id: "r3",
    lat: 6.518,
    lng: 3.391,
    color: "#f59e0b",
    type: "pothole",
    label: "Whittier Street",
  },
  {
    id: "r4",
    lat: 6.512,
    lng: 3.355,
    color: "#ef4444",
    type: "hazard",
    label: "Southwood Avenue",
  },
  {
    id: "r5",
    lat: 6.54,
    lng: 3.4,
    color: "#ef4444",
    type: "sos",
    label: "Dresden Street",
  },
  {
    id: "r6",
    lat: 6.5,
    lng: 3.38,
    color: "#2563eb",
    type: "sign",
    label: "Bretton Place",
  },
  {
    id: "r7",
    lat: 6.528,
    lng: 3.362,
    color: "#ef4444",
    type: "warning",
    label: "McDowell Street",
  },
  {
    id: "r8",
    lat: 6.515,
    lng: 3.41,
    color: "#f59e0b",
    type: "tractor",
    label: "Southwood Avenue",
  },
  {
    id: "r9",
    lat: 6.548,
    lng: 3.372,
    color: "#f59e0b",
    type: "hill",
    label: "McDowell Street",
  },
  {
    id: "r10",
    lat: 6.508,
    lng: 3.395,
    color: "#f59e0b",
    type: "pothole",
    label: "Dresden Street",
  },
  {
    id: "r11",
    lat: 6.532,
    lng: 3.348,
    color: "#ef4444",
    type: "hazard",
    label: "McDowell Street",
  },
  {
    id: "r12",
    lat: 6.495,
    lng: 3.385,
    color: "#f59e0b",
    type: "pothole",
    label: "Bretton Place",
  },
  {
    id: "r13",
    lat: 6.522,
    lng: 3.405,
    color: "#ef4444",
    type: "sos",
    label: "Bretton Place",
  },
  {
    id: "r14",
    lat: 6.505,
    lng: 3.36,
    color: "#f59e0b",
    type: "tractor",
    label: "Bretton Place",
  },
  {
    id: "r15",
    lat: 6.538,
    lng: 3.388,
    color: "#ef4444",
    type: "warning",
    label: "Bretton Place",
  },
];

// ─── ReportIcon Component ──────────────────────────────
function ReportIcon({
  type,
  selected,
}: {
  type: ReportType;
  selected?: boolean;
}) {
  const s = selected ? 1.25 : 1;
  switch (type) {
    case "wave":
      return (
        <svg
          viewBox="0 0 24 24"
          width={18 * s}
          height={18 * s}
          fill="none"
          stroke="white"
          strokeWidth="2"
          strokeLinecap="round"
        >
          <path d="M2 10c2-3 4-3 6 0s4 3 6 0 4-3 6 0" />
          <path d="M2 15c2-3 4-3 6 0s4 3 6 0 4-3 6 0" />
        </svg>
      );
    case "hill":
      return (
        <svg viewBox="0 0 24 24" width={18 * s} height={18 * s} fill="#3a2e1f">
          <path d="M2 18 L9 8 L13 13 L16 9 L22 18 Z" />
        </svg>
      );
    case "pothole":
      return (
        <svg viewBox="0 0 24 24" width={18 * s} height={18 * s}>
          <ellipse cx="12" cy="12" rx="8" ry="4.5" fill="#1a1a1a" />
        </svg>
      );
    case "hazard":
      return (
        <div
          style={{
            width: 18 * s,
            height: 14 * s,
            borderRadius: 2,
            backgroundImage:
              "repeating-linear-gradient(45deg, #f6c400 0 4px, #1a1a1a 4px 8px)",
          }}
        />
      );
    case "sos":
      return (
        <div className="bg-white rounded-[3px] px-1 py-0.5 flex items-center justify-center">
          <span className="text-red-600 font-extrabold text-[7px] leading-none">
            SOS
          </span>
        </div>
      );
    case "sign":
      return (
        <svg
          viewBox="0 0 24 24"
          width={18 * s}
          height={18 * s}
          fill="none"
          stroke="white"
          strokeWidth="2.2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <path d="M4 14 L14 4" />
          <path d="M9 4 L14 4 L14 9" />
          <path d="M20 10 L10 20" />
          <path d="M15 20 L10 20 L10 15" />
        </svg>
      );
    case "warning":
      return (
        <svg viewBox="0 0 24 24" width={18 * s} height={18 * s}>
          <path d="M12 3 L22 20 L2 20 Z" fill="white" />
          <rect x="11" y="10" width="2" height="5" fill="#e02424" />
          <rect x="11" y="16" width="2" height="2" fill="#e02424" />
        </svg>
      );
    case "tractor":
      return (
        <svg viewBox="0 0 24 24" width={18 * s} height={18 * s} fill="#2b2b2b">
          <rect x="8" y="8" width="7" height="5" rx="1" />
          <rect x="4" y="12" width="5" height="4" rx="1" />
          <circle
            cx="7"
            cy="18"
            r="3"
            fill="none"
            stroke="#2b2b2b"
            strokeWidth="2"
          />
          <circle
            cx="17"
            cy="18"
            r="4"
            fill="none"
            stroke="#2b2b2b"
            strokeWidth="2"
          />
        </svg>
      );
    default:
      return null;
  }
}

// ─── Hazard List Icon ──────────────────────────────────
function HazardListIcon({ type }: { type: ReportType }) {
  switch (type) {
    case "pothole":
      return (
        <div className="flex items-center justify-center bg-gray-100 w-9 h-9 sm:w-10 sm:h-10 rounded-xl">
          <svg
            viewBox="0 0 24 24"
            className="w-4.5 h-4.5 sm:w-5 sm:h-5"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
          >
            <ellipse cx="12" cy="12" rx="8" ry="4" fill="#1a1a1a" />
          </svg>
        </div>
      );
    case "hazard":
      return (
        <div className="flex items-center justify-center bg-blue-100 w-9 h-9 sm:w-10 sm:h-10 rounded-xl">
          <svg
            viewBox="0 0 24 24"
            className="w-4.5 h-4.5 sm:w-5 sm:h-5 text-blue-600"
            fill="currentColor"
          >
            <rect x="4" y="4" width="16" height="16" rx="3" />
            <text
              x="12"
              y="16"
              textAnchor="middle"
              fill="white"
              fontSize="10"
              fontWeight="bold"
            >
              P
            </text>
          </svg>
        </div>
      );
    default:
      return (
        <div className="flex items-center justify-center bg-gray-100 w-9 h-9 sm:w-10 sm:h-10 rounded-xl">
          <svg
            viewBox="0 0 24 24"
            className="w-4.5 h-4.5 sm:w-5 sm:h-5 text-gray-600"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
          >
            <path d="M12 9v4" />
            <path d="M12 17h.01" />
            <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" />
          </svg>
        </div>
      );
  }
}

// ─── Spinner Icon for loading state ──────────────────────
function SpinnerIcon({ className = "" }: { className?: string }) {
  return (
    <svg
      className={`animate-spin ${className}`}
      viewBox="0 0 24 24"
      fill="none"
    >
      <circle
        cx="12"
        cy="12"
        r="10"
        stroke="currentColor"
        strokeWidth="3"
        strokeDasharray="60"
        strokeDashoffset="20"
      />
    </svg>
  );
}

const WAKE_PHRASE = "hey driver";
const WAKE_WORD_STORAGE_KEY = "wakeWordEnabled";

// ─── Active trip persistence ──────────────────────────────
const ACTIVE_TRIP_STORAGE_KEY = "activeTrip";

type StoredActiveTrip = {
  startPoint: string;
  destination: string;
  startCoords: { lat: number; lng: number } | null;
  destinationCoords: { lat: number; lng: number } | null;
  selectedMode: RouteModeKey;
};

function readStoredActiveTrip(): StoredActiveTrip | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.sessionStorage.getItem(ACTIVE_TRIP_STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as StoredActiveTrip;
    if (!parsed.destinationCoords) return null;
    return parsed;
  } catch {
    return null;
  }
}

function writeStoredActiveTrip(trip: StoredActiveTrip) {
  if (typeof window === "undefined") return;
  try {
    window.sessionStorage.setItem(
      ACTIVE_TRIP_STORAGE_KEY,
      JSON.stringify(trip),
    );
  } catch {
    // sessionStorage can throw in private-browsing modes
  }
}

function clearStoredActiveTrip() {
  if (typeof window === "undefined") return;
  try {
    window.sessionStorage.removeItem(ACTIVE_TRIP_STORAGE_KEY);
  } catch {
    // no-op
  }
}

// ─── Main Component ────────────────────────────────────
export default function PlanRoutePage() {
  const navigate = useNavigate();
  const routerLocation = useLocation();
  // A place's "Directions" button (see HomePage's PlaceDetailSheet) sends
  // us here with the destination already picked, instead of making the
  // user retype it — read it once on mount. Consumed by the effect near
  // handleUseMyLocation below, which waits for a start point too before
  // actually kicking off route planning.
  const incomingDestinationRef = useRef<{
    lat: number;
    lng: number;
    label: string;
  } | null>(
    (() => {
      const state = routerLocation.state as
        | { destinationCoords?: { lat: number; lng: number }; destinationLabel?: string }
        | null
        | undefined;
      if (!state?.destinationCoords) return null;
      return {
        lat: state.destinationCoords.lat,
        lng: state.destinationCoords.lng,
        label: state.destinationLabel ?? "",
      };
    })(),
  );

  const isLoggedIn =
    typeof window !== "undefined" && !!localStorage.getItem("token");
  const [showAuth, setShowAuth] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);

  const { data: unreadCountData } = useUnreadCount();
  const unreadCount = unreadCountData?.count ?? 0;

  const { data: notificationsData, isLoading: notificationsLoading } =
    useNotificationsList({ limit: 20, offset: 0 });
  const notifications = notificationsData?.notifications ?? [];

  const markAllRead = useMarkAllRead();
  const markNotificationRead = useMarkNotificationRead();

  const mustAuthenticateAsFleetOwner = useFleetOwnerGate();

  useEffect(() => {
    if (mustAuthenticateAsFleetOwner) {
      setShowAuth(true);
    }
  }, [mustAuthenticateAsFleetOwner]);

  // ── TanStack Query: Profile ─────────────────────────
  const { data: profile, isLoading: profileLoading } = useQuery({
    queryKey: ["userProfile"],
    queryFn: getUserProfile,
    retry: false,
    staleTime: 5 * 60 * 1000,
    enabled: isLoggedIn,
  });

  // ── State ───────────────────────────────────────────
  const [showPlanModal, setShowPlanModal] = useState(false);
  const [showScanResults, setShowScanResults] = useState(false);
  const [isNavigating, setIsNavigating] = useState(false);
  const [showSOS, setShowSOS] = useState(false);
  const [sosHolding, setSosHolding] = useState(false);
  const [sosProgress, setSosProgress] = useState(0);
  const [showUpcomingAlert, setShowUpcomingAlert] = useState(false);
  const [streetViewOpen, setStreetViewOpen] = useState(false);

  const [selectedMode, setSelectedMode] = useState<RouteModeKey>("driving");

  const [navPanelExpanded, setNavPanelExpanded] = useState(true);
  const [topStackExpanded, setTopStackExpanded] = useState(true);
  const [selectedPin, setSelectedPin] = useState<string | null>(null);

  const [startPoint, setStartPoint] = useState("");
  const [destination, setDestination] = useState("");

  const [startCoords, setStartCoords] = useState<{
    lat: number;
    lng: number;
  } | null>(null);
  const [destinationCoords, setDestinationCoords] = useState<{
    lat: number;
    lng: number;
  } | null>(null);
  const [routeError, setRouteError] = useState<string | null>(null);
  const [activeSosId, setActiveSosId] = useState<string | null>(null);
  const [sosError, setSosError] = useState<string | null>(null);

  // ── Pick start/destination by tapping the map ──────────
  // Lets the driver drop a pin for a spot that doesn't have a name Places
  // Autocomplete would recognize (a gate, a specific compound entrance,
  // an unmarked junction) — addresses issue where the desired location
  // isn't reachable through search at all.
  const [pickingLocationFor, setPickingLocationFor] = useState<
    "start" | "destination" | null
  >(null);
  const [isMapPickLoading, setIsMapPickLoading] = useState(false);
  const [mapPickError, setMapPickError] = useState<string | null>(null);

  const beginMapPick = useCallback((target: "start" | "destination") => {
    setMapPickError(null);
    setPickingLocationFor(target);
    setShowPlanModal(false);
  }, []);

  const cancelMapPick = useCallback(() => {
    setPickingLocationFor(null);
    setMapPickError(null);
    setShowPlanModal(true);
  }, []);

  const handleMapPickSelect = useCallback(
    async (lat: number, lng: number) => {
      if (!pickingLocationFor) return;
      const target = pickingLocationFor;
      setIsMapPickLoading(true);
      setMapPickError(null);
      try {
        const { address } = await reverseGeocode(lat, lng);
        if (target === "start") {
          setStartPoint(address);
          setStartCoords({ lat, lng });
        } else {
          setDestination(address);
          setDestinationCoords({ lat, lng });
        }
        setPickingLocationFor(null);
        setShowPlanModal(true);
      } catch {
        setMapPickError("Couldn't get an address for that spot. Try tapping again.");
      } finally {
        setIsMapPickLoading(false);
      }
    },
    [pickingLocationFor],
  );

  const planRouteMutation = usePlanRouteOptions();
  const triggerSosMutation = useTriggerSos();
  const cancelSosMutation = useCancelSos();

  const routePlan = planRouteMutation.data;
  const activeRoute = routePlan?.routes[selectedMode];

  const alternativeRoutes = useMemo(
    () => getRouteAlternatives(activeRoute, 2),
    [activeRoute],
  );

  const [selectedRouteIndex, setSelectedRouteIndex] = useState<number | null>(
    null,
  );

  useEffect(() => {
    setSelectedRouteIndex(null);
  }, [routePlan, selectedMode]);

  type RouteChoice = {
    key: string;
    label: string;
    index: number | null;
    distance: number;
    duration: number;
    path: RouteOption["path"];
  };

  const routeChoices = useMemo<RouteChoice[]>(() => {
    if (!activeRoute) return [];
    const choices: RouteChoice[] = [
      {
        key: "primary",
        label: "Recommended",
        index: null,
        distance: activeRoute.distance,
        duration: activeRoute.duration,
        path: activeRoute.path,
      },
    ];
    alternativeRoutes.forEach((alt, i) => {
      choices.push({
        key: `alt-${i}`,
        label: `Alternative ${i + 1}`,
        index: i,
        distance: alt.distance,
        duration: alt.duration,
        path: alt.path,
      });
    });
    return choices;
  }, [activeRoute, alternativeRoutes]);

  const selectedChoice =
    routeChoices.find((c) => c.index === selectedRouteIndex) ?? routeChoices[0];

  const effectiveRoute = useMemo<RouteOption | undefined>(() => {
    if (!activeRoute || !selectedChoice || selectedChoice.index === null)
      return activeRoute;
    const alt: RouteAlternative | undefined =
      alternativeRoutes[selectedChoice.index];
    if (!alt) return activeRoute;
    return {
      ...activeRoute,
      path: alt.path,
      distance: alt.distance || activeRoute.distance,
      duration: alt.duration || activeRoute.duration,
      durationInSeconds: (alt.duration || activeRoute.duration) * 60,
      durationFormatted: alt.durationFormatted ?? activeRoute.durationFormatted,
      summary: alt.summary ?? activeRoute.summary,
      safetyScore: alt.safetyScore ?? activeRoute.safetyScore,
      safetyLevel: alt.safetyLevel ?? activeRoute.safetyLevel,
    };
  }, [activeRoute, selectedChoice, alternativeRoutes]);

  const routePath = useMemo(
    () => getRoutePath(effectiveRoute),
    [effectiveRoute],
  );

  const secondaryRoutes = useMemo(
    () =>
      routeChoices
        .filter((c) => c.key !== selectedChoice?.key)
        .map((c) => ({
          path: getRoutePath({ ...activeRoute, path: c.path } as RouteOption),
          onClick: () => setSelectedRouteIndex(c.index),
        })),
    [routeChoices, selectedChoice, activeRoute],
  );

  const availableModes = useMemo<RouteModeKey[]>(
    () => (routePlan ? (Object.keys(routePlan.routes) as RouteModeKey[]) : []),
    [routePlan],
  );

  useEffect(() => {
    if (!routePlan) return;
    const preferred = pickDefaultMode(routePlan);
    if (preferred) setSelectedMode(preferred);
  }, [routePlan]);

  const tripDurationMs = useMemo(() => {
    if (!effectiveRoute) return 30000;
    return Math.min(
      90000,
      Math.max(20000, effectiveRoute.durationInSeconds * 60),
    );
  }, [effectiveRoute]);

  const trip = useRouteAnimation({
    path: routePath,
    durationMs: tripDurationMs,
    autoPlay: false,
    loop: false,
  });

  // ── Geolocation State ────────────────────────────────
  const [isGettingLocation, setIsGettingLocation] = useState(false);
  const [locationError, setLocationError] = useState<string | null>(null);
  const [userLocation, setUserLocation] = useState<[number, number] | null>(
    null,
  );
  // Coarse, IP-based approximation used ONLY while real GPS hasn't
  // resolved yet (denied/unavailable/timed out) — keeps the map centered
  // somewhere near the user's actual area instead of jumping to the
  // hardcoded sample-report location (which is what made it look like it
  // was always stuck on one fixed city).
  const [ipFallbackLocation, setIpFallbackLocation] = useState<
    [number, number] | null
  >(null);
  const [mapReady, setMapReady] = useState(false);

  // ── Map display controls ─────
  const pageContainerRef = useRef<HTMLDivElement>(null);
  const [mapInstance, setMapInstance] = useState<google.maps.Map | null>(null);
  const [mapTypeId, setMapTypeId] = useState<MapTypeId>("roadmap");
  const [mapTilt, setMapTilt] = useState(0);
  const [showTraffic, setShowTraffic] = useState(true);
  const [manualHeading, setManualHeading] = useState(0);

  const routeCum = useMemo(() => cumulativeDistances(routePath), [routePath]);
  // Kept in sync every render so the GPS watch effect (which deliberately
  // does not depend on routePath/routeCum — see below) can always project
  // against the current route without needing to restart on every reroute.
  const routePathRef = useRef(routePath);
  routePathRef.current = routePath;
  const routeCumRef = useRef(routeCum);
  routeCumRef.current = routeCum;
  const [liveProgress, setLiveProgress] = useState<number | null>(null);
  const [liveHeading, setLiveHeading] = useState(0);

  const [routeDeviationMeters, setRouteDeviationMeters] = useState<
    number | null
  >(null);
  const [isRerouting, setIsRerouting] = useState(false);

  const [gpsStatus, setGpsStatus] = useState<"waiting" | "active" | "error">(
    "waiting",
  );
  const [gpsErrorMessage, setGpsErrorMessage] = useState<string | null>(null);
  const [gpsAccuracyMeters, setGpsAccuracyMeters] = useState<number | null>(
    null,
  );

  useEffect(() => {
    if (!isNavigating || routePath.length < 2) {
      setLiveProgress(null);
      return;
    }

    if (!navigator.geolocation) {
      setGpsStatus("error");
      setGpsErrorMessage("Geolocation is not supported on this device");
      return;
    }

    setGpsStatus("waiting");
    setGpsErrorMessage(null);

    let watchId: number;
    let usingFallback = false;

    const onPosition = (position: GeolocationPosition) => {
      const raw: LatLng = {
        lat: position.coords.latitude,
        lng: position.coords.longitude,
      };
      // Read the current route off refs, not the effect's closed-over
      // routePath/routeCum — this effect intentionally does NOT restart
      // when the route changes (see below), so it needs the live values.
      const path = routePathRef.current;
      const cum = routeCumRef.current;
      const projection = projectPointOntoPath(path, cum, raw);
      const sample = pointAtFraction(path, cum, projection.fraction);

      setGpsStatus("active");
      setLiveProgress(projection.fraction);
      setLiveHeading(sample.heading);
      setRouteDeviationMeters(projection.distanceMeters);
      setUserLocation([raw.lat, raw.lng]);
      setGpsAccuracyMeters(position.coords.accuracy ?? null);
    };

    const startWatch = (options: PositionOptions) => {
      watchId = navigator.geolocation.watchPosition(
        onPosition,
        (err) => {
          console.warn("[gps] watchPosition error:", err.message);

          if (!usingFallback && err.code === err.TIMEOUT) {
            usingFallback = true;
            navigator.geolocation.clearWatch(watchId);
            startWatch({
              enableHighAccuracy: false,
              maximumAge: 5000,
              timeout: 20000,
            });
            return;
          }

          setGpsStatus("error");
          setGpsErrorMessage(err.message || "Unable to get your location");
        },
        options,
      );
    };

    startWatch({ enableHighAccuracy: true, maximumAge: 2000, timeout: 15000 });

    return () => navigator.geolocation.clearWatch(watchId);
    // Deliberately NOT depending on routePath/routeCum: a reroute (traffic
    // replan or off-route recalculation) produces a new array reference
    // every time, which used to tear down and restart the GPS watch and
    // flash the "GPS waiting" banner on every replan. onPosition reads the
    // latest path/cum from refs instead, so tracking stays continuous
    // across route changes and only actually restarts if navigation itself
    // starts/stops.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isNavigating]);

  // ── Keep navigating through background/lock, resume cleanly ─────
  // Mobile browsers dim/lock the screen and heavily throttle timers, rAF,
  // and geolocation watches once the tab is backgrounded — from the
  // driver's side that reads as the app "hibernating" mid-trip. A Wake
  // Lock keeps the screen (and therefore GPS updates) alive while a trip
  // is active, and a visibilitychange listener grabs one fresh GPS fix
  // the instant the driver comes back so the view snaps to their real
  // position — right where they left off — instead of sitting frozen on
  // stale data until the next throttled watchPosition tick fires.
  // Typed `any`: the Screen Wake Lock API's TS lib types aren't guaranteed
  // to be present in every tsconfig, and this project's isn't in scope here.
  const wakeLockRef = useRef<any>(null);

  useEffect(() => {
    if (!isNavigating) {
      wakeLockRef.current?.release().catch(() => {});
      wakeLockRef.current = null;
      return;
    }

    let cancelled = false;

    const acquireWakeLock = async () => {
      if (!("wakeLock" in navigator)) return;
      try {
        const sentinel = await (navigator as any).wakeLock.request("screen");
        if (cancelled) {
          sentinel.release().catch(() => {});
          return;
        }
        wakeLockRef.current = sentinel;
      } catch {
        // Refused (low battery, backgrounded tab, unsupported context, etc.)
        // — non-fatal, the trip just won't hold the screen awake.
      }
    };

    acquireWakeLock();

    const handleVisibilityChange = () => {
      if (document.visibilityState === "visible") {
        // Wake Lock is released automatically on hide and must be
        // re-requested by hand once the page is visible again.
        acquireWakeLock();

        if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition(
            (position) => {
              setUserLocation([
                position.coords.latitude,
                position.coords.longitude,
              ]);
              setGpsAccuracyMeters(position.coords.accuracy ?? null);
              setGpsStatus("active");
            },
            () => {
              // Ignore — the regular watchPosition loop will keep trying.
            },
            { enableHighAccuracy: true, maximumAge: 0, timeout: 10000 },
          );
        }
      } else {
        wakeLockRef.current?.release().catch(() => {});
        wakeLockRef.current = null;
      }
    };

    document.addEventListener("visibilitychange", handleVisibilityChange);

    return () => {
      cancelled = true;
      document.removeEventListener("visibilitychange", handleVisibilityChange);
      wakeLockRef.current?.release().catch(() => {});
      wakeLockRef.current = null;
    };
  }, [isNavigating]);

  const displayProgress = liveProgress ?? trip.progress;
  const displayHeading = liveProgress != null ? liveHeading : trip.heading;

  const OFF_ROUTE_THRESHOLD_METERS = 40;
  const isOffRoute =
    isNavigating &&
    liveProgress != null &&
    (routeDeviationMeters ?? 0) > OFF_ROUTE_THRESHOLD_METERS;

  const turnByTurn = useTurnByTurn(routePath, displayProgress, isNavigating);

  const sosTimerRef = useRef<ReturnType<typeof window.setInterval> | null>(
    null,
  );
  const sosProgressRef = useRef(0);

  // ── SOS Hold Logic ──────────────────────────────────
  const startSOSHold = useCallback(() => {
    if (showSOS) return;
    setSosHolding(true);
    sosProgressRef.current = 0;
    setSosProgress(0);

    sosTimerRef.current = window.setInterval(() => {
      sosProgressRef.current += 2;
      setSosProgress(sosProgressRef.current);
      if (sosProgressRef.current >= 100) {
        if (sosTimerRef.current) window.clearInterval(sosTimerRef.current);
        setSosHolding(false);
        setSosProgress(0);
        sosProgressRef.current = 0;
        setSosError(null);

        if (!userLocation) {
          setSosError(
            "Unable to get your location. Please enable location access and try again.",
          );
          return;
        }

        setShowSOS(true);

        const [lat, lng] = userLocation;
        console.log("[sos] triggering SOS at", { lat, lng });
        triggerSosMutation.mutate(
          { latitude: lat, longitude: lng },
          {
            onSuccess: (data) => {
              console.log("[sos] triggered successfully", data);
              if (data?.id) setActiveSosId(data.id);
            },
            onError: (err) => {
              console.error("[sos] failed to trigger", err);
              const status = err instanceof ApiError ? err.status : undefined;
              const message =
                err instanceof Error ? err.message : "Failed to send SOS alert";

              if (status === 401) {
                setShowSOS(false);
                setShowAuth(true);
                return;
              }

              setSosError(message);
            },
          },
        );
      }
    }, 60);
  }, [showSOS, userLocation, triggerSosMutation]);

  const endSOSHold = useCallback(() => {
    if (sosTimerRef.current) window.clearInterval(sosTimerRef.current);
    setSosHolding(false);
    setSosProgress(0);
    sosProgressRef.current = 0;
  }, []);

  useEffect(() => {
    return () => {
      if (sosTimerRef.current) window.clearInterval(sosTimerRef.current);
    };
  }, []);

  // ── Reverse geocode via backend ──
  const reverseGeocodeStartPoint = useCallback(
    async (lat: number, lng: number) => {
      try {
        const { address } = await reverseGeocode(lat, lng);
        setStartPoint(address);
        setStartCoords({ lat, lng });
      } catch (err) {
        setStartPoint(`${lat.toFixed(4)}, ${lng.toFixed(4)}`);
        setStartCoords({ lat, lng });
      } finally {
        setIsGettingLocation(false);
      }
    },
    [],
  );

  useEffect(() => {
    if (!navigator.geolocation) {
      setLocationError("Geolocation not supported by your browser");
      setMapReady(true);
      return;
    }

    const onSuccess = (position: GeolocationPosition) => {
      const loc: [number, number] = [
        position.coords.latitude,
        position.coords.longitude,
      ];
      setUserLocation(loc);
      setMapReady(true);
    };

    const onFinalError = async (error: GeolocationPositionError) => {
      let message = "Unable to retrieve your location";
      switch (error.code) {
        case error.PERMISSION_DENIED:
          message = "Location permission denied. Please enable it in settings.";
          break;
        case error.POSITION_UNAVAILABLE:
          message = "Location information unavailable.";
          break;
        case error.TIMEOUT:
          message = "Location request timed out.";
          break;
      }
      setLocationError(message);
      setMapReady(true);

      // GPS didn't work — approximate from the network/IP address so the
      // map still centers near the user instead of the sample data point.
      const ipLocation = await getIpLocation();
      if (ipLocation) {
        setIpFallbackLocation([ipLocation.latitude, ipLocation.longitude]);
      }
    };

    // Go straight for a high-accuracy fix instead of trying a cheap
    // low-accuracy one first: the first pass could return a stale
    // (up to 60s old) cell/Wi-Fi position and cost several seconds
    // before falling back anyway. If it's denied, report that
    // immediately rather than silently retrying (retrying after a
    // denial just triggers the same denial again).
    navigator.geolocation.getCurrentPosition(onSuccess, onFinalError, {
      enableHighAccuracy: true,
      timeout: 15000,
      maximumAge: 0,
    });
  }, []);

  useEffect(() => {
    const previousOverscroll = document.body.style.overscrollBehavior;
    document.body.style.overscrollBehavior = "none";
    return () => {
      document.body.style.overscrollBehavior = previousOverscroll;
    };
  }, []);

  const handleUseMyLocation = useCallback(() => {
    if (!navigator.geolocation) {
      setLocationError("Geolocation not supported by your browser");
      return;
    }
    setIsGettingLocation(true);
    setLocationError(null);

    const onSuccess = (position: GeolocationPosition) => {
      const loc: [number, number] = [
        position.coords.latitude,
        position.coords.longitude,
      ];
      setUserLocation(loc);
      reverseGeocodeStartPoint(
        position.coords.latitude,
        position.coords.longitude,
      );
    };

    const onFinalError = async (error: GeolocationPositionError) => {
      let message = "Unable to retrieve your location";
      switch (error.code) {
        case error.PERMISSION_DENIED:
          message = "Location permission denied. Please enable it in settings.";
          break;
        case error.POSITION_UNAVAILABLE:
          message = "Location information unavailable.";
          break;
        case error.TIMEOUT:
          message = "Location request timed out.";
          break;
      }
      setLocationError(message);

      // The user explicitly asked for their location and GPS couldn't
      // deliver — fall back to an IP-based approximation rather than
      // leaving them on the sample-data location, while still surfacing
      // the error above so they know it isn't a precise GPS fix.
      const ipLocation = await getIpLocation();
      if (ipLocation) {
        const loc: [number, number] = [
          ipLocation.latitude,
          ipLocation.longitude,
        ];
        setIpFallbackLocation(loc);
        reverseGeocodeStartPoint(ipLocation.latitude, ipLocation.longitude);
      } else {
        setIsGettingLocation(false);
      }
    };

    navigator.geolocation.getCurrentPosition(onSuccess, onFinalError, {
      enableHighAccuracy: true,
      timeout: 15000,
      maximumAge: 0,
    });
  }, [reverseGeocodeStartPoint]);

  // ── Arriving here from a place's "Directions" button ─────
  // Fill in the destination that was picked back on the map/home screen,
  // then get a real GPS fix for the start point (rather than leaving the
  // user to type both in by hand) and kick the route plan off as soon as
  // both are ready, so the route actually draws on this page's own map.
  const hasAppliedIncomingDestinationRef = useRef(false);
  useEffect(() => {
    if (hasAppliedIncomingDestinationRef.current) return;
    const incoming = incomingDestinationRef.current;
    if (!incoming) return;
    hasAppliedIncomingDestinationRef.current = true;

    setDestination(
      incoming.label || `${incoming.lat.toFixed(4)}, ${incoming.lng.toFixed(4)}`,
    );
    setDestinationCoords({ lat: incoming.lat, lng: incoming.lng });
    handleUseMyLocation();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!incomingDestinationRef.current) return;
    if (!startPoint || !startCoords || !destinationCoords) return;

    // Both points are ready — clear the pending marker first so this
    // can't fire twice (e.g. if startPoint changes again later), then
    // run the same planning path the manual "Scan route" button uses.
    incomingDestinationRef.current = null;
    handleScanRoute();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [startPoint, startCoords, destinationCoords]);

  const handleRecenter = useCallback(() => {
    if (userLocation && mapInstance) {
      mapInstance.panTo({ lat: userLocation[0], lng: userLocation[1] });
      if ((mapInstance.getZoom() ?? 15) < 15) {
        mapInstance.setZoom(16);
      }
      return;
    }
    handleUseMyLocation();
  }, [userLocation, mapInstance, handleUseMyLocation]);

  // ── Route Logic ─────────────────────────────────────
  const handleScanRoute = () => {
    console.log("[route] scan route clicked", {
      startPoint,
      destination,
      startCoords,
      destinationCoords,
      userLocation,
    });

    if (!startPoint || !destination) {
      console.log("[route] blocked: startPoint or destination text is empty");
      return;
    }

    const origin =
      startCoords ??
      (userLocation ? { lat: userLocation[0], lng: userLocation[1] } : null);
    const dest = destinationCoords;

    if (!origin || !dest) {
      console.log("[route] blocked: missing coordinates", { origin, dest });
      setRouteError(
        "Pick both points from the suggestions so we have exact coordinates.",
      );
      return;
    }

    console.log("[route] planning route with payload", {
      origin,
      destination: dest,
    });
    setRouteError(null);
    setShowPlanModal(false);
    setShowScanResults(true);

    planRouteMutation.mutate(
      { origin, destination: dest },
      {
        onSuccess: (data) => {
          console.log("[route] plan succeeded", data);
        },
        onError: (err) => {
          console.error("[route] plan failed", err);
          const status = err instanceof ApiError ? err.status : undefined;
          const message =
            err instanceof Error ? err.message : "Failed to plan route";

          if (status === 401) {
            setShowScanResults(false);
            setShowAuth(true);
            return;
          }

          setRouteError(message);
        },
      },
    );
  };

  const handleStartTrip = () => {
    voiceGuidance.unlock();
    setShowScanResults(false);
    setIsNavigating(true);
    setNavPanelExpanded(true);
    setGpsStatus("waiting");
    setGpsErrorMessage(null);
    trip.reset();

    writeStoredActiveTrip({
      startPoint,
      destination,
      startCoords,
      destinationCoords,
      selectedMode,
    });

    if (destinationCoords) {
      recordVisitedPlace({
        label: destination || "Dropped pin",
        lat: destinationCoords.lat,
        lng: destinationCoords.lng,
      });
    }

    announcedArrivalRef.current = false;
    announcedOffRouteRef.current = false;
    lastMilestoneKmRef.current = null;

    const distanceLabel = effectiveRoute
      ? `${effectiveRoute.distance.toFixed(1)} kilometers`
      : "";
    const etaLabel = effectiveRoute
      ? `about ${Math.round(effectiveRoute.duration)} minutes`
      : "";
    void (async () => {
      await voiceGuidance.speak(
        "trip.starting",
        { destination: destination || "your destination" },
        {
          interrupt: true,
          fallbackText: `Starting navigation${destination ? " to " + destination : ""}.${distanceLabel ? " " + distanceLabel : ""}${etaLabel ? ", " + etaLabel : ""}.`,
        },
      );
      if (effectiveRoute) {
        await voiceGuidance.speak(
          "trip.remaining_km",
          { km: effectiveRoute.distance.toFixed(1) },
          { fallbackText: distanceLabel },
        );
        await voiceGuidance.speak(
          "trip.eta_minutes",
          { minutes: String(Math.round(effectiveRoute.duration)) },
          { fallbackText: etaLabel },
        );
      }
    })();

    setTimeout(() => setShowUpcomingAlert(true), 2000);
    setTimeout(() => setShowUpcomingAlert(false), 9000);
  };

  const handleEndTrip = () => {
    voiceGuidance.stop();
    setIsNavigating(false);
    setShowUpcomingAlert(false);
    setStartPoint("");
    setDestination("");
    setShowScanResults(false);
    setRouteError(null);
    trip.pause();
    trip.reset();
    setLiveProgress(null);
    setRouteDeviationMeters(null);
    setIsRerouting(false);
    setGpsStatus("waiting");
    setGpsErrorMessage(null);
    planRouteMutation.reset();
    lastTrafficDurationRef.current = null;
    setTrafficNotice(null);
    clearStoredActiveTrip();
    navigate("/home");
  };

  const resumedActiveTripRef = useRef(false);
  const pendingResumeDestRef = useRef<{ lat: number; lng: number } | null>(
    null,
  );
  const resumeReplanFiredRef = useRef(false);

  useEffect(() => {
    if (resumedActiveTripRef.current) return;
    resumedActiveTripRef.current = true;

    const stored = readStoredActiveTrip();
    if (!stored || !stored.destinationCoords) return;

    setStartPoint(stored.startPoint);
    setDestination(stored.destination);
    setStartCoords(stored.startCoords);
    setDestinationCoords(stored.destinationCoords);
    setSelectedMode(stored.selectedMode);
    setShowPlanModal(false);
    setShowScanResults(false);
    setIsNavigating(true);
    setNavPanelExpanded(true);

    pendingResumeDestRef.current = stored.destinationCoords;
  }, []);

  useEffect(() => {
    const dest = pendingResumeDestRef.current;
    if (!dest || resumeReplanFiredRef.current) return;

    // Prefer the live GPS position so the route picks up from the
    // driver's current location; fall back to the location they
    // started from if we couldn't get a fresh fix (permission denied,
    // GPS unavailable, etc.) so the trip doesn't get stuck.
    const origin = userLocation
      ? { lat: userLocation[0], lng: userLocation[1] }
      : locationError
        ? startCoords
        : null;
    if (!origin) return;

    resumeReplanFiredRef.current = true;
    pendingResumeDestRef.current = null;
    planRouteMutation.mutate({ origin, destination: dest });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userLocation, locationError]);

  // ── Live traffic: periodic re-plan while navigating ───────────
  const userLocationRef = useRef(userLocation);
  userLocationRef.current = userLocation;

  const lastTrafficDurationRef = useRef<number | null>(null);
  const [trafficNotice, setTrafficNotice] = useState<string | null>(null);
  const TRAFFIC_RECALC_INTERVAL_MS = 120000;
  const TRAFFIC_NOTICE_THRESHOLD_MIN = 2;

  useEffect(() => {
    if (!isNavigating || !destinationCoords) return;
    const dest = destinationCoords;

    if (lastTrafficDurationRef.current == null && effectiveRoute) {
      lastTrafficDurationRef.current = effectiveRoute.duration;
    }

    const interval = setInterval(() => {
      const loc = userLocationRef.current;
      if (!loc) return;

      planRouteMutation.mutate(
        { origin: { lat: loc[0], lng: loc[1] }, destination: dest },
        {
          onSuccess: (data) => {
            const updated = data.routes[selectedMode];
            if (!updated) return;

            const previous = lastTrafficDurationRef.current;
            lastTrafficDurationRef.current = updated.duration;

            if (previous == null) return;
            const deltaMin = Math.round(updated.duration - previous);

            if (Math.abs(deltaMin) >= TRAFFIC_NOTICE_THRESHOLD_MIN) {
              setTrafficNotice(
                deltaMin > 0
                  ? `Traffic ahead — route updated, +${deltaMin} min`
                  : `Traffic cleared — route updated, ${Math.abs(deltaMin)} min faster`,
              );
              setTimeout(() => setTrafficNotice(null), 7000);
            }
          },
        },
      );
    }, TRAFFIC_RECALC_INTERVAL_MS);

    return () => clearInterval(interval);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isNavigating, destinationCoords, selectedMode]);

  // ── Collision Guard ─────────────────────────────────
  const [collisionGuardEnabled, setCollisionGuardEnabled] = useState(false);
  const [collisionGuardExpanded, setCollisionGuardExpanded] = useState(false);
  const collisionGuard = useCollisionGuard(
    collisionGuardEnabled && isNavigating,
  );

  const lastSpokenCollisionRef = useRef<{
    id: string;
    severity: string;
    at: number;
  } | null>(null);

  useEffect(() => {
    const warning = collisionGuard.activeWarning;
    if (!collisionGuardEnabled || !isNavigating || !warning) return;

    const last = lastSpokenCollisionRef.current;
    const sameAndRecent =
      last &&
      last.id === warning.id &&
      last.severity === warning.severity &&
      Date.now() - last.at < 8000;
    if (sameAndRecent) return;

    lastSpokenCollisionRef.current = {
      id: warning.id,
      severity: warning.severity,
      at: Date.now(),
    };
    voiceGuidance.speakText(describeWarning(warning), {
      interrupt: warning.severity === "high",
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [collisionGuard.activeWarning, collisionGuardEnabled, isNavigating]);

  // ── Arrival ──
  // Arrival is judged purely on proximity to the destination pin, the same
  // way Google Maps does it — not on how far along the route polyline we've
  // projected. Requiring both meant a route whose polyline didn't terminate
  // exactly on the destination coordinate (routing snaps to the nearest
  // road, not the literal pin) could keep displayProgress just under 0.995
  // forever, so "arrived" would never fire even when the user was standing
  // right there.
  const ARRIVAL_RADIUS_METERS = 50;
  const distanceToDestinationMeters =
    userLocation && destinationCoords
      ? haversineMeters(
          { lat: userLocation[0], lng: userLocation[1] },
          destinationCoords,
        )
      : null;

  // Widen the radius when the GPS fix itself is noisy, so a jittery signal
  // near the destination doesn't cause a missed arrival.
  const effectiveArrivalRadiusMeters = Math.max(
    ARRIVAL_RADIUS_METERS,
    gpsAccuracyMeters ?? 0,
  );

  const hasArrived =
    isNavigating &&
    distanceToDestinationMeters != null &&
    distanceToDestinationMeters <= effectiveArrivalRadiusMeters;

  const upcomingHazard = describeUpcomingHazard(effectiveRoute?.hazards);

  // ── Top-stack alert priority ──────────────────────────
  const activeTopAlert:
    | "collision"
    | "offroute"
    | "gpserror"
    | "gpswaiting"
    | "hazard"
    | null =
    collisionGuardEnabled && collisionGuard.activeWarning
      ? "collision"
      : isOffRoute
        ? "offroute"
        : gpsStatus === "error"
          ? "gpserror"
          : gpsStatus === "waiting"
            ? "gpswaiting"
            : showUpcomingAlert && !hasArrived && upcomingHazard
              ? "hazard"
              : null;

  const navHazardCount = activeRoute?.hazards?.length ?? 0;
  const remainingKm = effectiveRoute
    ? Math.max(0, effectiveRoute.distance * (1 - displayProgress))
    : 0;
  const etaMinutes = effectiveRoute
    ? Math.max(0, Math.round(effectiveRoute.duration * (1 - displayProgress)))
    : 0;

  // ── Arrival time (ETA as a clock time) ──
  const formatClockTime = useCallback((minutesFromNow: number) => {
    const arrival = new Date(Date.now() + Math.max(0, minutesFromNow) * 60000);
    return arrival.toLocaleTimeString([], {
      hour: "numeric",
      minute: "2-digit",
    });
  }, []);

  const plannedArrivalLabel = effectiveRoute
    ? formatClockTime(effectiveRoute.duration)
    : null;

  const liveArrivalLabel = effectiveRoute ? formatClockTime(etaMinutes) : null;

  // ── Turn-by-turn voice guidance ──────────────────────
  const voiceGuidance = useMultilingualVoiceGuidance();
  const announcedArrivalRef = useRef(false);
  const announcedOffRouteRef = useRef(false);
  const lastMilestoneKmRef = useRef<number | null>(null);

  const remainingKmFloor =
    isNavigating && effectiveRoute && !hasArrived
      ? Math.floor(remainingKm)
      : null;

  useEffect(() => {
    if (remainingKmFloor == null) return;
    if (lastMilestoneKmRef.current === remainingKmFloor) return;
    const isFirstReading = lastMilestoneKmRef.current === null;
    lastMilestoneKmRef.current = remainingKmFloor;
    if (isFirstReading || remainingKmFloor <= 0) return;
    void (async () => {
      await voiceGuidance.speak(
        "trip.remaining_km",
        { km: String(remainingKmFloor) },
        {
          fallbackText: `${remainingKmFloor} kilometer${remainingKmFloor === 1 ? "" : "s"} remaining.`,
        },
      );
      await voiceGuidance.speak(
        "trip.eta_minutes",
        { minutes: String(etaMinutes) },
        {
          fallbackText: `E.T.A. ${etaMinutes} minute${etaMinutes === 1 ? "" : "s"}.`,
        },
      );
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [remainingKmFloor]);

  // Bumped to force the reroute effect below to re-evaluate after a failed
  // recalculation attempt, even though `isOffRoute` itself hasn't changed
  // (a ref flip alone doesn't trigger a re-render/effect run).
  const [rerouteRetryTick, setRerouteRetryTick] = useState(0);

  useEffect(() => {
    if (!isNavigating) {
      announcedOffRouteRef.current = false;
      return;
    }
    if (isOffRoute && !announcedOffRouteRef.current && !isRerouting) {
      announcedOffRouteRef.current = true;
      voiceGuidance.speak(
        "trip.off_route",
        {},
        { interrupt: true, fallbackText: "You've gone off route. Recalculating." },
      );

      // Actually recalculate: replan from wherever the driver currently is
      // back to the same destination. planRouteMutation's result feeds
      // `routePlan` → `activeRoute` → `routePath`, so once this resolves
      // the map, turn-by-turn list, and off-route check all pick up the
      // new route automatically — same mechanism the periodic traffic
      // replan below already relies on.
      const loc = userLocationRef.current;
      if (loc && destinationCoords) {
        setIsRerouting(true);
        planRouteMutation.mutate(
          { origin: { lat: loc[0], lng: loc[1] }, destination: destinationCoords },
          {
            onSuccess: (data) => {
              const updated = data.routes[selectedMode];
              if (updated) {
                lastTrafficDurationRef.current = updated.duration;
              }
            },
            onError: () => {
              // A failed recalculation used to be a dead end: the ref stayed
              // "announced" so this effect never fired again while still
              // off-route, leaving the driver stuck with turn-by-turn steps
              // built from the route to the turn they already missed. Clear
              // the flag and force a retry shortly instead.
              window.setTimeout(() => {
                announcedOffRouteRef.current = false;
                setRerouteRetryTick((t) => t + 1);
              }, 3000);
            },
            onSettled: () => setIsRerouting(false),
          },
        );
      }
    } else if (!isOffRoute) {
      announcedOffRouteRef.current = false;
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isOffRoute, isNavigating, rerouteRetryTick]);

  useEffect(() => {
    if (hasArrived && !announcedArrivalRef.current) {
      announcedArrivalRef.current = true;
      voiceGuidance.speak(
        "trip.arrived",
        {},
        { interrupt: true, fallbackText: "You've arrived at your destination." },
      );
    }
    if (!isNavigating) announcedArrivalRef.current = false;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [hasArrived, isNavigating]);

  useEffect(() => {
    if (showUpcomingAlert && isNavigating && !hasArrived && upcomingHazard) {
      const hazardType = (effectiveRoute?.hazards as any[] | undefined)?.[0]
        ?.type;
      const { key, params } = resolveHazardPhrase(
        hazardType,
        upcomingHazard.label,
      );
      voiceGuidance.speak(key, params, {
        fallbackText: `Caution: ${upcomingHazard.label} ahead.`,
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [showUpcomingAlert]);

  // ── Turn-by-turn maneuver call-outs ──────────────────
  const MANEUVER_WARN_METERS = 300;
  const MANEUVER_NOW_METERS = 30;
  const announcedWarnRef = useRef<string | null>(null);
  const announcedNowRef = useRef<string | null>(null);

  useEffect(() => {
    if (!isNavigating || hasArrived) return;
    const step = turnByTurn.currentStep;
    if (!step || step.type === "arrive") return;

    const distance = turnByTurn.distanceToNextManeuverMeters;
    const instruction = describeManeuver(step, turnByTurn.nextRoadName);
    const { key: maneuverKey, params: maneuverParams } = resolveManeuverPhrase(
      step,
      turnByTurn.nextRoadName,
    );

    if (
      distance <= MANEUVER_WARN_METERS &&
      announcedWarnRef.current !== step.id
    ) {
      announcedWarnRef.current = step.id;
      voiceGuidance.speakManeuverWithDistance(
        maneuverKey,
        maneuverParams,
        distance,
        {
          fallbackText: `In ${formatManeuverDistance(distance)}, ${instruction.charAt(0).toLowerCase()}${instruction.slice(1)}.`,
        },
      );
    }

    if (
      distance <= MANEUVER_NOW_METERS &&
      announcedNowRef.current !== step.id
    ) {
      announcedNowRef.current = step.id;
      // Only cut off whatever's currently speaking if the warn call-out for
      // this same maneuver never got a chance to play (e.g. a very short
      // segment). Otherwise let it finish naturally — this queues right
      // behind it instead of chopping it off mid-sentence.
      voiceGuidance.speak(maneuverKey, maneuverParams, {
        interrupt: announcedWarnRef.current !== step.id,
        fallbackText: `${instruction} now.`,
      });
    }

    if (turnByTurn.nextStep) {
      const next = resolveManeuverPhrase(
        turnByTurn.nextStep,
        turnByTurn.nextRoadName,
      );
      voiceGuidance.warm(next.key, next.params);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    isNavigating,
    hasArrived,
    turnByTurn.currentStep?.id,
    turnByTurn.distanceToNextManeuverMeters,
    turnByTurn.nextRoadName,
  ]);

  useEffect(() => {
    if (!isNavigating) {
      announcedWarnRef.current = null;
      announcedNowRef.current = null;
    }
  }, [isNavigating]);

  const [wakeWordEnabled, setWakeWordEnabled] = useState(
    () =>
      typeof window !== "undefined" &&
      window.localStorage.getItem(WAKE_WORD_STORAGE_KEY) === "1",
  );
  useEffect(() => {
    try {
      window.localStorage.setItem(
        WAKE_WORD_STORAGE_KEY,
        wakeWordEnabled ? "1" : "0",
      );
    } catch {
      // ignore
    }
  }, [wakeWordEnabled]);

  const destinationVoiceSearch = useVoiceSearch();
  const [voiceCaptureStatus, setVoiceCaptureStatus] = useState<
    "idle" | "listening" | "searching"
  >("idle");

  const captureDestinationByVoice = useCallback(() => {
    voiceGuidance.unlock();
    setRouteError(null);
    setShowPlanModal(true);
    setVoiceCaptureStatus("listening");
    voiceGuidance.speakText("Where would you like to go?", { interrupt: true });

    window.setTimeout(() => {
      destinationVoiceSearch.start(async (transcript) => {
        setDestination(transcript);
        setVoiceCaptureStatus("searching");
        try {
          const result = await forwardGeocode(transcript);
          if (
            typeof result.lat === "number" &&
            typeof result.lng === "number"
          ) {
            setDestination(result.address || transcript);
            setDestinationCoords({ lat: result.lat, lng: result.lng });
            voiceGuidance.speakText(
              `Got it — ${result.address || transcript}. Tap Scan Route when you're ready.`,
            );
          } else {
            voiceGuidance.speakText(
              "I couldn't find that place. Please pick it from the list.",
            );
          }
        } catch {
          voiceGuidance.speakText(
            "I couldn't find that place. Please pick it from the list.",
          );
        } finally {
          setVoiceCaptureStatus("idle");
        }
      });
    }, 1200);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [destinationVoiceSearch]);

  const wakeWord = useWakeWord({
    phrase: WAKE_PHRASE,
    enabled: wakeWordEnabled && !isNavigating && !showPlanModal,
    onWake: captureDestinationByVoice,
  });

  const mapCenter = useMemo<[number, number]>(
    () =>
      userLocation || ipFallbackLocation || [reports[0].lat, reports[0].lng],
    [userLocation, ipFallbackLocation],
  );

  const mapMarkers = useMemo<MapMarkerSpec[]>(() => {
    const markers: MapMarkerSpec[] = reports.map((r) => {
      const isSelected = r.id === selectedPin;
      return {
        id: r.id,
        lat: r.lat,
        lng: r.lng,
        html: reportPinHtml(r.color, isSelected, r.type),
        anchor: getReportPinAnchor(isSelected),
        onClick: () => setSelectedPin(isSelected ? null : r.id),
      };
    });

    if (userLocation && !isNavigating) {
      markers.push({
        id: "__user_location__",
        lat: userLocation[0],
        lng: userLocation[1],
        html: userLocationPinHtml,
        anchor: USER_LOCATION_ANCHOR,
      });
    }

    if (effectiveRoute && routePath.length > 0) {
      const destPoint = destinationCoords ?? routePath[routePath.length - 1];
      markers.push({
        id: "__destination__",
        lat: destPoint.lat,
        lng: destPoint.lng,
        html: destinationPinHtml(),
        anchor: DESTINATION_PIN_ANCHOR,
      });

      if (!isNavigating) {
        const originPoint = startCoords ?? routePath[0];
        markers.push({
          id: "__start__",
          lat: originPoint.lat,
          lng: originPoint.lng,
          html: startPinHtml,
          anchor: START_PIN_ANCHOR,
        });
      }
    }

    return markers;
  }, [
    selectedPin,
    userLocation,
    isNavigating,
    effectiveRoute,
    routePath,
    destinationCoords,
    startCoords,
  ]);

  // ── Profile Helpers ──────────────────────────────────
  const avatarInitials = useMemo(() => {
    if (!isLoggedIn) return "?";
    if (profileLoading || !profile) return profileLoading ? "..." : "??";
    return `${profile.firstName[0] ?? ""}${profile.lastName[0] ?? ""}`.toUpperCase();
  }, [isLoggedIn, profile, profileLoading]);

  const displayName = useMemo(() => {
    if (!isLoggedIn) return "Welcome 👋";
    if (profileLoading) return "Loading...";
    if (!profile) return "Welcome 👋";
    return `Good Afternoon 👋`;
  }, [isLoggedIn, profile, profileLoading]);

  const subtitleText = useMemo(() => {
    if (!isLoggedIn) return "Tap to sign in";
    if (profileLoading) return "...";
    if (!profile) return "Guest";
    if (profile.driverProfile?.address) return profile.driverProfile.address;
    return `${profile.firstName} ${profile.lastName}`;
  }, [isLoggedIn, profile, profileLoading]);

  const handleProfileBarClick = () => {
    if (!isLoggedIn) {
      setShowAuth(true);
      return;
    }
    navigate("/profile");
  };

  const handleNotificationsClick = () => {
    if (!isLoggedIn) {
      setShowAuth(true);
      return;
    }
    setShowNotifications(true);
  };

  if (!mapReady) {
    return (
      <div className="flex flex-col items-center justify-center h-[100dvh] w-full bg-gray-100">
        <div className="w-10 h-10 mb-4 border-4 border-red-500 rounded-full sm:w-12 sm:h-12 border-t-transparent animate-spin" />
        <p className="text-sm font-medium text-gray-600 sm:text-base">
          Getting your location...
        </p>
        {locationError && (
          <p className="px-8 mt-2 text-xs text-center text-red-500 sm:text-sm">
            {locationError}
          </p>
        )}
      </div>
    );
  }

  return (
    <div
      ref={pageContainerRef}
      className="fixed inset-0 w-full h-[100dvh] overflow-hidden bg-gray-100"
    >
      <div className="absolute inset-0 z-0">
        {effectiveRoute ? (
          <RouteMapView
            route={effectiveRoute}
            markers={mapMarkers}
            zoom={isNavigating ? 18 : 15}
            progress={isNavigating ? displayProgress : undefined}
            flowing={!isNavigating}
            heading={isNavigating ? displayHeading : manualHeading}
            interactive={!isNavigating}
            followMode={isNavigating}
            secondaryRoutes={isNavigating ? undefined : secondaryRoutes}
            mapTypeId={mapTypeId}
            tilt={mapTilt}
            showTraffic={showTraffic}
            onReady={setMapInstance}
            className="w-full h-full"
            strokeWeight={isNavigating ? 11 : 8}
            puckSize={isNavigating ? 46 : 32}
          />
        ) : (
          <LazyGoogleMap
            center={{ lat: mapCenter[0], lng: mapCenter[1] }}
            zoom={15}
            markers={mapMarkers}
            heading={manualHeading}
            mapTypeId={mapTypeId}
            tilt={mapTilt}
            showTraffic={showTraffic}
            onReady={setMapInstance}
            onMapClick={
              pickingLocationFor && !isMapPickLoading
                ? handleMapPickSelect
                : undefined
            }
          />
        )}
      </div>

      {/* Pick-on-map banner */}
      {pickingLocationFor && (
        <div className="absolute left-0 right-0 z-[70] flex justify-center top-[calc(1rem+env(safe-area-inset-top))] px-4">
          <div className="flex items-center gap-3 px-4 py-3 bg-white shadow-lg rounded-2xl max-w-sm">
            <MapPinned size={18} className="flex-shrink-0 text-purple-600" />
            <div className="flex-1 min-w-0">
              <p className="text-xs font-medium text-gray-900 sm:text-sm">
                {isMapPickLoading
                  ? "Getting address…"
                  : `Tap the map to set your ${pickingLocationFor === "start" ? "start point" : "destination"}`}
              </p>
              {mapPickError && (
                <p className="mt-0.5 text-[11px] text-red-500">{mapPickError}</p>
              )}
            </div>
            <button
              type="button"
              onClick={cancelMapPick}
              className="shrink-0 text-xs sm:text-sm font-medium text-gray-500 hover:text-gray-700"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Map Controls */}
      {!showPlanModal && !showScanResults && !showSOS && !pickingLocationFor && (
        <MapControls
          map={mapInstance}
          mapTypeId={mapTypeId}
          onMapTypeChange={setMapTypeId}
          tilt={mapTilt}
          onToggleTilt={() => setMapTilt((t) => (t > 0 ? 0 : 45))}
          trafficEnabled={showTraffic}
          onToggleTraffic={() => setShowTraffic((t) => !t)}
          heading={isNavigating ? displayHeading : manualHeading}
          onHeadingChange={setManualHeading}
          rotatable={!isNavigating}
          onRecenter={handleRecenter}
          isLocating={isGettingLocation}
          fullscreenTargetRef={pageContainerRef}
          className={`transition-[bottom] ${
            isNavigating
              ? navPanelExpanded
                ? "bottom-[21rem]"
                : "bottom-[13rem]"
              : "bottom-[15rem]"
          }`}
        />
      )}

      {/* Location error toast */}
      {locationError && !showPlanModal && !showScanResults && !showSOS && (
        <div className="absolute top-4 left-4 right-4 sm:left-1/2 sm:right-auto sm:-translate-x-1/2 sm:w-full sm:max-w-md z-[500] bg-yellow-50 border border-yellow-200 rounded-xl px-4 py-3 flex items-start gap-3">
          <div className="text-yellow-600 mt-0.5">⚠️</div>
          <div className="flex-1 min-w-0">
            <p className="text-xs font-medium text-yellow-800 sm:text-sm">
              {locationError}
            </p>
            <p className="mt-1 text-[11px] sm:text-xs text-yellow-600">
              Showing default area
            </p>
          </div>
          <button
            onClick={handleUseMyLocation}
            disabled={isGettingLocation}
            className="flex-shrink-0 text-[11px] sm:text-xs font-semibold text-yellow-800 underline disabled:opacity-50"
          >
            {isGettingLocation ? "Retrying…" : "Retry"}
          </button>
        </div>
      )}

      {/* Collision Guard */}
      {collisionGuardEnabled && isNavigating && (
        <CollisionGuardView
          guard={collisionGuard}
          expanded={collisionGuardExpanded}
          onToggleExpanded={() => setCollisionGuardExpanded((v) => !v)}
          onClose={() => setCollisionGuardEnabled(false)}
        />
      )}

      {/* Traffic recalculation toast */}
      {trafficNotice && isNavigating && (
        <div className="absolute top-4 left-4 right-4 sm:left-1/2 sm:right-auto sm:-translate-x-1/2 sm:w-full sm:max-w-md z-[500] bg-white shadow-lg border border-gray-100 rounded-xl px-4 py-3 flex items-center gap-3">
          <span className="text-lg">🚦</span>
          <p className="text-xs font-medium text-gray-800 sm:text-sm">
            {trafficNotice}
          </p>
        </div>
      )}

      {/* Home Header */}
      {!isNavigating && !showScanResults && (
        <div className="absolute top-0 left-0 right-0 z-20 px-4 pt-6 pb-2 sm:pt-12 sm:flex sm:justify-center">
          <div className="sm:w-full sm:max-w-md">
            <div className="flex items-center gap-2 mb-3">
              <button
                onClick={handleProfileBarClick}
                className="flex items-center flex-1 gap-3 px-4 py-3 text-left bg-white shadow-sm rounded-2xl"
              >
                <div className="flex items-center justify-center text-xs font-bold text-white bg-purple-600 rounded-full w-9 h-9 sm:w-10 sm:h-10 sm:text-sm">
                  {avatarInitials}
                </div>
                <div>
                  <p className="text-xs font-semibold text-gray-900 sm:text-sm">
                    {displayName}
                  </p>
                  <p className="text-[11px] sm:text-xs text-purple-600">
                    {subtitleText}
                  </p>
                </div>
              </button>

              <button
                onClick={handleNotificationsClick}
                aria-label="Notifications"
                className="relative flex items-center justify-center flex-shrink-0 bg-white shadow-sm w-11 h-11 sm:w-12 sm:h-12 rounded-2xl"
              >
                <svg
                  viewBox="0 0 24 24"
                  className="w-5 h-5 text-gray-700 sm:w-6 sm:h-6"
                  fill="currentColor"
                >
                  <path d="M12 22c1.1 0 2-.9 2-2h-4c0 1.1.9 2 2 2zm6-6v-5c0-3.07-1.63-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.64 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2z" />
                </svg>
                {isLoggedIn && unreadCount > 0 && (
                  <span className="absolute top-2 right-2 w-2.5 h-2.5 bg-red-500 rounded-full border-2 border-white" />
                )}
              </button>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  setRouteError(null);
                  setShowPlanModal(true);
                }}
                className="flex items-center flex-1 gap-3 px-4 py-3.5 text-left bg-white shadow-sm rounded-2xl"
              >
                <svg
                  viewBox="0 0 24 24"
                  className="flex-shrink-0 w-4.5 h-4.5 sm:w-5 sm:h-5 text-gray-400"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <circle cx="11" cy="11" r="8" />
                  <path d="m21 21-4.35-4.35" />
                </svg>
                <span className="flex-1 text-xs text-gray-400 truncate sm:text-sm">
                  {voiceCaptureStatus === "listening"
                    ? "Listening…"
                    : voiceCaptureStatus === "searching"
                      ? "Finding that place…"
                      : "Where are you going?"}
                </span>
              </button>

              {destinationVoiceSearch.isSupported && (
                <button
                  onClick={captureDestinationByVoice}
                  aria-label="Search by voice"
                  className={`flex items-center justify-center flex-shrink-0 w-12 h-12 rounded-2xl shadow-sm transition ${
                    voiceCaptureStatus !== "idle"
                      ? "bg-purple-600 text-white animate-pulse"
                      : "bg-white text-purple-600"
                  }`}
                >
                  <Mic size={18} />
                </button>
              )}
            </div>

            {wakeWord.isSupported && !wakeWord.permissionDenied && (
              <button
                onClick={() => setWakeWordEnabled((v) => !v)}
                className="flex items-center gap-1.5 px-3 py-1.5 mt-2 bg-white rounded-full shadow-sm w-fit"
              >
                <span
                  className={`relative inline-flex h-4 w-7 items-center rounded-full transition flex-shrink-0 ${
                    wakeWordEnabled ? "bg-purple-600" : "bg-gray-300"
                  }`}
                >
                  <span
                    className={`inline-block h-3 w-3 transform rounded-full bg-white transition ${
                      wakeWordEnabled ? "translate-x-3.5" : "translate-x-0.5"
                    }`}
                  />
                </span>
                <span className="text-[11px] font-medium text-gray-700">
                  {wakeWordEnabled
                    ? `Listening for "Hey Driver"${wakeWord.isListening ? "" : "…"}`
                    : 'Hands-free "Hey Driver" — off'}
                </span>
              </button>
            )}
          </div>
        </div>
      )}

      {/* Scan Results Header */}
      {showScanResults && (
        <div className="absolute top-0 left-0 right-0 z-20 px-4 pt-12 pb-2 sm:flex sm:justify-center">
          <div className="px-4 py-3 mb-3 bg-white shadow-sm rounded-2xl sm:w-full sm:max-w-md">
            <div className="flex items-center gap-3 mb-3">
              <div className="flex items-center justify-center rounded-full w-7 h-7 sm:w-8 sm:h-8 bg-emerald-100">
                <svg
                  viewBox="0 0 24 24"
                  className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-emerald-600"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                >
                  <circle cx="12" cy="12" r="10" />
                  <path d="M12 8v4l3 3" />
                </svg>
              </div>
              <div className="flex-1">
                <p className="text-xs font-semibold text-gray-900 sm:text-sm">
                  {startPoint || "Lekki Phase 1"}
                </p>
                <p className="text-[11px] sm:text-xs text-gray-400">From</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="flex items-center justify-center bg-red-100 rounded-full w-7 h-7 sm:w-8 sm:h-8">
                <svg
                  viewBox="0 0 24 24"
                  className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-red-500"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                >
                  <path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z" />
                  <line x1="4" y1="22" x2="4" y2="15" />
                </svg>
              </div>
              <div className="flex-1">
                <p className="text-xs font-semibold text-gray-900 sm:text-sm">
                  {destination || "3rd Avenue Market St"}
                </p>
                <p className="text-[11px] sm:text-xs text-gray-400">To</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Navigation Top Stack */}
      {isNavigating && (
        <div className="absolute top-0 left-0 right-0 z-20 px-4 pt-[calc(env(safe-area-inset-top)+0.75rem)] pb-2 sm:flex sm:justify-center">
          <div className="space-y-2 sm:w-full sm:max-w-md">
            <div
              className={`flex items-center gap-2 sm:gap-3 px-3 py-2 sm:px-4 sm:py-3 shadow-sm rounded-xl sm:rounded-2xl ${hasArrived ? "bg-purple-600" : "bg-emerald-500"}`}
            >
              <div className="flex items-center justify-center w-8 h-8 rounded-lg sm:w-10 sm:h-10 sm:rounded-xl bg-white/20">
                <svg
                  viewBox="0 0 24 24"
                  className="w-4 h-4 text-white sm:w-5 sm:h-5"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2.5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  {hasArrived ? (
                    <path d="M20 6L9 17l-5-5" />
                  ) : (
                    <path d="M12 19V5M5 12l7-7 7 7" />
                  )}
                </svg>
              </div>
              <div className="flex-1">
                <p className="text-[9px] sm:text-xs font-medium tracking-wide uppercase text-white/80">
                  {hasArrived
                    ? "Trip complete"
                    : `${remainingKm.toFixed(1)} KM left`}
                </p>
                <p className="text-[11px] sm:text-sm font-semibold text-white">
                  {hasArrived
                    ? "You've arrived"
                    : "Head out and follow the route"}
                </p>
              </div>
              {voiceGuidance.isSupported && (
                <VoiceGuidanceControl
                  muted={voiceGuidance.muted}
                  toggleMuted={voiceGuidance.toggleMuted}
                  volume={voiceGuidance.volume}
                  setVolume={voiceGuidance.setVolume}
                  locale={voiceGuidance.locale}
                  setLocale={voiceGuidance.setLocale}
                  locales={voiceGuidance.locales}
                />
              )}
              {collisionGuard.isSupported && (
                <button
                  onClick={() => setCollisionGuardEnabled((v) => !v)}
                  aria-label={
                    collisionGuardEnabled
                      ? "Turn off Collision Guard"
                      : "Turn on Collision Guard"
                  }
                  title="Collision Guard — forward-collision warning"
                  className={`flex items-center justify-center flex-shrink-0 w-8 h-8 sm:w-10 sm:h-10 rounded-lg sm:rounded-xl transition ${
                    collisionGuardEnabled
                      ? "bg-white text-emerald-600"
                      : "bg-white/20 text-white"
                  }`}
                >
                  <svg
                    viewBox="0 0 24 24"
                    className="w-4 h-4 sm:w-5 sm:h-5"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M12 3l8 4v5c0 4.5-3.4 8.3-8 9-4.6-.7-8-4.5-8-9V7l8-4z" />
                    <path d="M9.5 12l1.8 1.8L15 10" />
                  </svg>
                </button>
              )}
              <button
                onClick={() => setTopStackExpanded((v) => !v)}
                aria-label={
                  topStackExpanded
                    ? "Collapse trip details"
                    : "Expand trip details"
                }
                className="flex items-center justify-center flex-shrink-0 w-8 h-8 text-white transition rounded-lg sm:w-10 sm:h-10 sm:rounded-xl bg-white/20 hover:bg-white/30"
              >
                <svg
                  viewBox="0 0 24 24"
                  className={`w-4 h-4 sm:w-5 sm:h-5 transition-transform ${topStackExpanded ? "rotate-180" : ""}`}
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2.5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M6 9l6 6 6-6" />
                </svg>
              </button>
            </div>

            {topStackExpanded && !hasArrived && turnByTurn.currentStep && (
              <TurnByTurnCard
                step={turnByTurn.currentStep}
                distanceMeters={turnByTurn.distanceToNextManeuverMeters}
                currentRoadName={turnByTurn.currentRoadName}
                nextRoadName={turnByTurn.nextRoadName}
              />
            )}

            {topStackExpanded && activeTopAlert === "gpswaiting" && (
              <div className="flex items-center gap-3 px-4 py-3 bg-white shadow-sm rounded-xl animate-in slide-in-from-top-2">
                <div className="flex items-center justify-center flex-shrink-0 bg-blue-100 rounded-lg w-7 h-7 sm:w-8 sm:h-8">
                  <div className="w-3.5 h-3.5 sm:w-4 sm:h-4 border-2 border-blue-500 rounded-full border-t-transparent animate-spin" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-[9px] sm:text-[10px] text-gray-400 font-medium uppercase tracking-wide">
                    GPS
                  </p>
                  <p className="text-xs font-medium text-gray-900 truncate sm:text-sm">
                    Waiting for your location…
                  </p>
                </div>
              </div>
            )}

            {topStackExpanded && activeTopAlert === "gpserror" && (
              <div className="flex items-center gap-3 px-4 py-3 border shadow-sm bg-amber-50 border-amber-200 rounded-xl animate-in slide-in-from-top-2">
                <div className="flex items-center justify-center flex-shrink-0 rounded-lg w-7 h-7 sm:w-8 sm:h-8 bg-amber-100">
                  <svg
                    viewBox="0 0 24 24"
                    className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-amber-600"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M12 9v4M12 17h.01M10.29 3.86l-8.18 14.18A2 2 0 0 0 3.82 21h16.36a2 2 0 0 0 1.71-2.96L13.71 3.86a2 2 0 0 0-3.42 0z" />
                  </svg>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-[9px] sm:text-[10px] text-amber-500 font-medium uppercase tracking-wide">
                    GPS unavailable
                  </p>
                  <p className="text-xs font-medium truncate text-amber-900 sm:text-sm">
                    {gpsErrorMessage}
                  </p>
                </div>
              </div>
            )}

            {topStackExpanded && activeTopAlert === "offroute" && (
              <div className="flex items-center gap-3 px-4 py-3 border border-red-200 shadow-sm bg-red-50 rounded-xl animate-in slide-in-from-top-2">
                <div className="flex items-center justify-center flex-shrink-0 bg-red-100 rounded-lg w-7 h-7 sm:w-8 sm:h-8">
                  <svg
                    viewBox="0 0 24 24"
                    className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-red-600"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M12 9v4M12 17h.01M10.29 3.86l-8.18 14.18A2 2 0 0 0 3.82 21h16.36a2 2 0 0 0 1.71-2.96L13.71 3.86a2 2 0 0 0-3.42 0z" />
                  </svg>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-[9px] sm:text-[10px] text-red-400 font-medium uppercase tracking-wide">
                    {isRerouting ? "Rerouting…" : "Off route"}
                  </p>
                  <p className="text-xs font-medium text-red-900 truncate sm:text-sm">
                    {isRerouting
                      ? "Finding a new route from where you are"
                      : `You've drifted ${Math.round(routeDeviationMeters ?? 0)}m from the planned path`}
                  </p>
                </div>
              </div>
            )}

            {activeTopAlert === "collision" &&
              collisionGuard.activeWarning &&
              (() => {
                const warning = collisionGuard.activeWarning;
                const isHigh = warning.severity === "high";
                return (
                  <div
                    className={`flex items-center gap-3 px-4 py-3 border shadow-sm rounded-xl animate-in slide-in-from-top-2 ${
                      isHigh
                        ? "bg-red-50 border-red-200"
                        : "bg-amber-50 border-amber-200"
                    }`}
                  >
                    <div
                      className={`flex items-center justify-center flex-shrink-0 rounded-lg w-7 h-7 sm:w-8 sm:h-8 ${
                        isHigh ? "bg-red-100" : "bg-amber-100"
                      }`}
                    >
                      <span className="text-sm leading-none sm:text-base">
                        {isHigh ? "🚨" : "⚠️"}
                      </span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <p
                        className={`text-[9px] sm:text-[10px] font-medium uppercase tracking-wide ${
                          isHigh ? "text-red-400" : "text-amber-500"
                        }`}
                      >
                        Collision Guard
                      </p>
                      <p
                        className={`text-xs font-medium truncate sm:text-sm ${
                          isHigh ? "text-red-900" : "text-amber-900"
                        }`}
                      >
                        {describeWarning(warning)}
                      </p>
                    </div>
                  </div>
                );
              })()}

            {topStackExpanded &&
              activeTopAlert === "hazard" &&
              upcomingHazard && (
                <div className="flex items-center gap-3 px-4 py-3 bg-white shadow-sm rounded-xl animate-in slide-in-from-top-2">
                  <div className="flex items-center justify-center flex-shrink-0 rounded-lg w-7 h-7 sm:w-8 sm:h-8 bg-amber-100">
                    <span className="text-sm leading-none sm:text-base">
                      {upcomingHazard.icon}
                    </span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-[9px] sm:text-[10px] text-gray-400 font-medium uppercase tracking-wide">
                      Upcoming
                    </p>
                    <p className="text-xs font-medium text-gray-900 truncate sm:text-sm">
                      {upcomingHazard.label}
                    </p>
                  </div>
                  <button
                    onClick={() => setShowUpcomingAlert(false)}
                    aria-label="Dismiss"
                    className="flex items-center justify-center flex-shrink-0 w-6 h-6 text-gray-400 rounded-full active:bg-gray-100"
                  >
                    <svg
                      viewBox="0 0 24 24"
                      className="w-3.5 h-3.5"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2.2"
                      strokeLinecap="round"
                    >
                      <path d="M6 6l12 12M18 6L6 18" />
                    </svg>
                  </button>
                </div>
              )}
          </div>
        </div>
      )}

      {isNavigating && (
        <div className="absolute bottom-0 left-0 right-0 z-20 px-4 pb-[calc(5.0rem+env(safe-area-inset-bottom))] sm:flex sm:justify-center">
          <div className="sm:w-full sm:max-w-md">
            {navPanelExpanded ? (
              <div className="px-5 pt-3 pb-4 bg-white shadow-lg rounded-2xl">
                <button
                  onClick={() => setNavPanelExpanded(false)}
                  className="flex items-center justify-center w-full gap-1.5 py-1.5 mb-2 -mt-1 group"
                  aria-label="Collapse trip card"
                >
                  <span className="w-8 h-1 transition bg-gray-300 rounded-full group-active:bg-gray-400" />
                  <svg
                    viewBox="0 0 24 24"
                    className="w-3.5 h-3.5 text-gray-400"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M6 9l6 6 6-6" />
                  </svg>
                </button>

                <button
                  onClick={() => setNavPanelExpanded(false)}
                  aria-label="Collapse trip card"
                  className="grid w-full grid-cols-3 gap-2 mb-3"
                >
                  <div className="min-w-0 text-center">
                    <p className="text-[11px] sm:text-xs text-gray-400 mb-0.5">
                      ETA
                    </p>
                    <p className="text-lg font-bold text-gray-900 sm:text-xl">
                      {hasArrived ? "0 min" : `${etaMinutes} min`}
                    </p>
                    {!hasArrived && liveArrivalLabel && (
                      <p className="text-[10px] sm:text-[11px] text-gray-400 mt-0.5">
                        Arrive {liveArrivalLabel}
                      </p>
                    )}
                  </div>
                  <div className="min-w-0 text-center">
                    <p className="text-[11px] sm:text-xs text-gray-400 mb-0.5">
                      Remaining
                    </p>
                    <p className="text-lg font-bold text-gray-900 sm:text-xl">
                      {remainingKm.toFixed(1)} km
                    </p>
                  </div>
                  <div className="min-w-0 text-center">
                    <p className="text-[11px] sm:text-xs text-gray-400 mb-0.5">
                      Hazards
                    </p>
                    <p className="text-lg font-bold sm:text-xl text-amber-500">
                      {navHazardCount}
                    </p>
                  </div>
                </button>
                <button
                  onClick={handleEndTrip}
                  className="w-full h-11 sm:h-12 bg-red-500 hover:bg-red-600 text-white text-sm sm:text-base font-semibold rounded-xl transition active:scale-[0.98]"
                >
                  {hasArrived ? "Done" : "End Trip"}
                </button>
              </div>
            ) : (
              <button
                onClick={() => setNavPanelExpanded(true)}
                className="flex items-center w-full gap-3 py-2.5 pl-4 pr-2 bg-white shadow-lg rounded-full"
              >
                <span className="flex-1 text-xs font-semibold text-left text-gray-900 sm:text-sm">
                  {hasArrived
                    ? "You've arrived"
                    : `${etaMinutes} min · ${remainingKm.toFixed(1)} km left${
                        liveArrivalLabel ? ` · Arrive ${liveArrivalLabel}` : ""
                      }`}
                </span>
                <svg
                  viewBox="0 0 24 24"
                  className="w-4 h-4 text-gray-400"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2.5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M18 15l-6-6-6 6" />
                </svg>
                <span
                  onClick={(e) => {
                    e.stopPropagation();
                    handleEndTrip();
                  }}
                  role="button"
                  aria-label="End trip"
                  className="flex items-center justify-center flex-shrink-0 w-8 h-8 text-white bg-red-500 rounded-full active:scale-95"
                >
                  <svg
                    viewBox="0 0 24 24"
                    className="w-4 h-4"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2.5"
                    strokeLinecap="round"
                  >
                    <path d="M18 6L6 18M6 6l12 12" />
                  </svg>
                </span>
              </button>
            )}
          </div>
        </div>
      )}

      {!showSOS && !showPlanModal && !showScanResults && (
        <StreetViewPegman
          onClick={() => setStreetViewOpen(true)}
          className={`absolute z-[999] left-4 sm:left-8 transition-[bottom] ${
            isNavigating
              ? navPanelExpanded
                ? "bottom-56"
                : "bottom-24"
              : "bottom-32"
          }`}
        />
      )}

      <StreetViewModal
        isOpen={streetViewOpen}
        onClose={() => setStreetViewOpen(false)}
        lat={
          (
            destinationCoords ??
            routePath[routePath.length - 1] ?? {
              lat: mapCenter[0],
              lng: mapCenter[1],
            }
          ).lat
        }
        lng={
          (
            destinationCoords ??
            routePath[routePath.length - 1] ?? {
              lat: mapCenter[0],
              lng: mapCenter[1],
            }
          ).lng
        }
        label={destination || "Current location"}
      />

      {/* SOS Floating Button */}
      {!showSOS && (
        <div
          className={`absolute z-[999] right-4 sm:right-8 transition-[bottom] ${
            isNavigating
              ? navPanelExpanded
                ? "bottom-56"
                : "bottom-24"
              : "bottom-32"
          }`}
          onMouseDown={startSOSHold}
          onMouseUp={endSOSHold}
          onMouseLeave={endSOSHold}
          onTouchStart={(e) => {
            e.stopPropagation();
            startSOSHold();
          }}
          onTouchEnd={(e) => {
            e.stopPropagation();
            endSOSHold();
          }}
        >
          <span className="absolute inset-[-6px] rounded-full border-[3px] border-red-400/35 animate-ping pointer-events-none" />
          <span className="absolute inset-[-6px] rounded-full border-[3px] border-red-400/35 pointer-events-none" />

          {sosHolding && (
            <svg
              className="absolute inset-[-4px] w-[72px] h-[72px] sm:w-[88px] sm:h-[88px] -rotate-90 pointer-events-none"
              viewBox="0 0 88 88"
            >
              <circle
                cx="44"
                cy="44"
                r="42"
                fill="none"
                stroke="white"
                strokeWidth="4"
                strokeLinecap="round"
                strokeDasharray={2 * Math.PI * 42}
                strokeDashoffset={2 * Math.PI * 42 * (1 - sosProgress / 100)}
                style={{ transition: "stroke-dashoffset 0.05s linear" }}
              />
            </svg>
          )}

          <button
            className="relative flex flex-col items-center justify-center w-16 h-16 sm:w-20 sm:h-20 text-white transition rounded-full bg-[#ff4444] active:scale-95 overflow-hidden select-none"
            style={{
              touchAction: "none",
              WebkitTouchCallout: "none",
              WebkitUserSelect: "none",
              userSelect: "none",
              WebkitTapHighlightColor: "transparent",
            }}
          >
            <span className="text-[13px] sm:text-[15px] font-bold relative z-10 pointer-events-none">
              SOS
            </span>
            <span className="text-[9px] sm:text-[10px] opacity-90 relative z-10 pointer-events-none">
              {sosHolding ? "Hold..." : "Hold 3s"}
            </span>
          </button>
        </div>
      )}

      {/* ═══════════════════════════════════════════════════════
          PLAN ROUTE MODAL
          ═══════════════════════════════════════════════════════ */}
      {showPlanModal && (
        // <div className="fixed inset-0 z-[60] flex items-end sm:items-center justify-center bg-black/0 sm:bg-black/40">
        //   <div className="flex flex-col w-full h-full sm:h-auto sm:max-h-[85vh] sm:max-w-md bg-white animate-in slide-in-from-bottom sm:rounded-3xl sm:shadow-2xl overflow-hidden">
        <div className="fixed inset-0 z-[60] flex items-end sm:items-center sm:justify-center bg-black/20 pointer-events-none">
          <div
            className="
      pointer-events-auto
      flex flex-col
      w-full sm:max-w-md
      h-[88dvh] sm:h-auto sm:max-h-[80vh]
      bg-white
      rounded-t-[24px] sm:rounded-3xl
      shadow-2xl
      overflow-hidden
    "
          >
            <div className="flex-shrink-0 px-5 pt-5 pb-3">
              <div className="flex items-start justify-between">
                <div>
                  <h2 className="text-xl font-extrabold text-gray-900 sm:text-2xl">
                    Plan a route
                  </h2>
                  <p className="mt-1 text-xs text-gray-500 sm:text-sm">
                    We&apos;ll scan reported hazards along the way before you
                    drive.
                  </p>
                </div>
                <button
                  onClick={() => setShowPlanModal(false)}
                  className="flex items-center justify-center flex-shrink-0 w-8 h-8 text-gray-500 transition bg-gray-100 rounded-full sm:w-9 sm:h-9 hover:bg-gray-200"
                >
                  <svg
                    viewBox="0 0 24 24"
                    className="w-4.5 h-4.5 sm:w-5 sm:h-5"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2.5"
                    strokeLinecap="round"
                  >
                    <path d="M18 6L6 18M6 6l12 12" />
                  </svg>
                </button>
              </div>
            </div>

            <div className="flex-1 min-h-0 px-5 pt-2 space-y-4 overflow-y-auto overscroll-contain [-ms-overflow-style:none] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <div className="flex items-center justify-center w-5 h-5 border-2 rounded-full border-emerald-500">
                    <div className="w-2 h-2 rounded-full bg-emerald-500" />
                  </div>
                  <span className="text-xs font-medium text-gray-900 sm:text-sm">
                    Point A — Start
                  </span>
                </div>
                <div className="flex items-center gap-2 px-4 py-3 bg-gray-50 rounded-xl">
                  <AddressAutocompleteInput
                    value={startPoint}
                    onChange={setStartPoint}
                    onSelect={(result) =>
                      setStartCoords({ lat: result.lat, lng: result.lng })
                    }
                    placeholder="Search a place or Address"
                    className="flex-1 min-w-0"
                    inputClassName="w-full min-w-0 text-base text-gray-900 placeholder-gray-400 bg-transparent outline-none"
                    biasLocation={
                      userLocation
                        ? { lat: userLocation[0], lng: userLocation[1] }
                        : undefined
                    }
                  />
                  <button
                    type="button"
                    onClick={() => beginMapPick("start")}
                    aria-label="Pick start on map"
                    title="Pick on map"
                    className="shrink-0 flex items-center justify-center w-7 h-7 text-purple-600 hover:text-purple-700 hover:bg-purple-50 rounded-full transition"
                  >
                    <MapPinned size={16} />
                  </button>
                  <button
                    onClick={handleUseMyLocation}
                    disabled={isGettingLocation}
                    className="shrink-0 text-xs sm:text-sm font-medium text-purple-600 whitespace-nowrap hover:text-purple-700 disabled:opacity-50 flex items-center gap-1.5"
                  >
                    {isGettingLocation ? (
                      <>
                        <SpinnerIcon className="w-3.5 h-3.5" />
                        Locating...
                      </>
                    ) : (
                      "Use my location"
                    )}
                  </button>
                </div>
                {locationError && (
                  <p className="mt-1.5 ml-1 text-[11px] sm:text-xs text-red-500">
                    {locationError}
                  </p>
                )}
              </div>

              <div>
                <div className="flex items-center gap-2 mb-2">
                  <svg
                    viewBox="0 0 24 24"
                    className="w-4.5 h-4.5 sm:w-5 sm:h-5 text-red-400"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z" />
                    <line x1="4" y1="22" x2="4" y2="15" />
                  </svg>
                  <span className="text-xs font-medium text-gray-900 sm:text-sm">
                    Point B — Destination
                  </span>
                </div>
                <div className="flex items-center gap-2 px-4 py-3 bg-gray-50 rounded-xl">
                  <AddressAutocompleteInput
                    value={destination}
                    onChange={setDestination}
                    onSelect={(result) =>
                      setDestinationCoords({ lat: result.lat, lng: result.lng })
                    }
                    placeholder="Where to?"
                    className="flex-1 min-w-0"
                    inputClassName="w-full text-base text-gray-900 placeholder-gray-400 bg-transparent outline-none"
                    biasLocation={
                      userLocation
                        ? { lat: userLocation[0], lng: userLocation[1] }
                        : undefined
                    }
                  />
                  <button
                    type="button"
                    onClick={() => beginMapPick("destination")}
                    aria-label="Pick destination on map"
                    title="Pick on map"
                    className="shrink-0 flex items-center justify-center w-7 h-7 text-purple-600 hover:text-purple-700 hover:bg-purple-50 rounded-full transition"
                  >
                    <MapPinned size={16} />
                  </button>
                </div>
              </div>

              <div className="h-4" />
            </div>

            <div className="flex-shrink-0 px-5 pt-4 pb-[calc(7.25rem+env(safe-area-inset-bottom))] sm:pb-6">
              {routeError && (
                <p className="mb-3 text-xs text-center text-red-500 sm:text-sm">
                  {routeError}
                </p>
              )}
              <button
                onClick={handleScanRoute}
                disabled={!startPoint || !destination}
                className="w-full h-12 sm:h-14 bg-purple-700 hover:bg-purple-800 disabled:bg-gray-300 disabled:cursor-not-allowed text-white font-semibold text-sm sm:text-base rounded-2xl transition active:scale-[0.98]"
              >
                Scan route
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ═══════════════════════════════════════════════════════
          SCAN RESULTS BOTTOM SHEET  (RESPONSIVE FIX APPLIED)
          ═══════════════════════════════════════════════════════ */}
      {showScanResults && (
        <div className="fixed inset-0 z-[60] flex flex-col justify-end sm:justify-center sm:items-center bg-white/0 sm:bg-black/30 pointer-events-none">
          <div className="flex-1 sm:flex-none flex flex-col bg-white rounded-t-[24px] sm:rounded-3xl shadow-[0_-4px_24px_rgba(0,0,0,0.15)] sm:shadow-2xl pointer-events-auto overflow-hidden w-full sm:max-w-md max-h-[90vh] sm:max-h-[80vh]">
            <div className="flex justify-center flex-shrink-0 pt-3 pb-2 sm:hidden">
              <div className="w-10 h-1 bg-gray-300 rounded-full" />
            </div>

            <div className="flex-1 min-h-0 overflow-y-auto overscroll-contain px-5 pt-4 sm:pt-6 pb-4 [-ms-overflow-style:none] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
              {planRouteMutation.isPending && (
                <div className="flex flex-col items-center justify-center gap-3 py-10">
                  <SpinnerIcon className="w-6 h-6 text-purple-600" />
                  <p className="text-xs text-gray-500 sm:text-sm">
                    Scanning route for hazards...
                  </p>
                </div>
              )}

              {!planRouteMutation.isPending && routeError && (
                <div className="flex items-center gap-2 px-4 py-3 mb-4 border border-red-100 bg-red-50 rounded-xl">
                  <p className="text-xs font-medium text-red-700 sm:text-sm">
                    {routeError}
                  </p>
                </div>
              )}

              {!planRouteMutation.isPending && !routeError && (
                <>
                  {availableModes.length > 1 && (
                    <div className="flex gap-2 mb-4 overflow-x-auto [-ms-overflow-style:none] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
                      {availableModes.map((mode) => (
                        <button
                          key={mode}
                          onClick={() => setSelectedMode(mode)}
                          className={`flex-shrink-0 px-3.5 py-2 rounded-full text-xs sm:text-sm font-semibold whitespace-nowrap transition ${
                            mode === selectedMode
                              ? "bg-purple-700 text-white"
                              : "bg-gray-100 text-gray-600"
                          }`}
                        >
                          {routePlan?.routes[mode]?.label ?? mode}
                        </button>
                      ))}
                    </div>
                  )}

                  {alternativeRoutes.length > 0 && (
                    <div className="flex gap-2 mb-4 overflow-x-auto [-ms-overflow-style:none] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
                      {routeChoices.map((choice) => (
                        <button
                          key={choice.key}
                          onClick={() => setSelectedRouteIndex(choice.index)}
                          className={`flex-shrink-0 min-w-[104px] px-3.5 py-2 rounded-xl text-left transition border ${
                            choice.key === selectedChoice?.key
                              ? "bg-purple-50 border-purple-600"
                              : "bg-gray-50 border-transparent"
                          }`}
                        >
                          <p
                            className={`text-[11px] sm:text-xs font-semibold whitespace-nowrap ${
                              choice.key === selectedChoice?.key
                                ? "text-purple-700"
                                : "text-gray-600"
                            }`}
                          >
                            {choice.label}
                          </p>
                          <p className="text-xs font-bold text-gray-900 sm:text-sm whitespace-nowrap">
                            {choice.distance.toFixed(1)} km ·{" "}
                            {Math.round(choice.duration)} min
                          </p>
                        </button>
                      ))}
                    </div>
                  )}

                  <div className="grid grid-cols-3 gap-3 mb-4">
                    <div className="p-3 text-center bg-gray-50 rounded-2xl">
                      <p className="text-base font-bold text-gray-900 sm:text-lg">
                        {effectiveRoute
                          ? `${effectiveRoute.distance.toFixed(1)} km`
                          : "9.5 km"}
                      </p>
                      <p className="text-[11px] sm:text-xs text-gray-400 mt-0.5">
                        Distance
                      </p>
                    </div>
                    <div className="p-3 text-center bg-gray-50 rounded-2xl">
                      <p className="text-base font-bold text-gray-900 sm:text-lg">
                        {effectiveRoute
                          ? `${Math.round(effectiveRoute.duration)} min`
                          : "23 min"}
                      </p>
                      <p className="text-[11px] sm:text-xs text-gray-400 mt-0.5">
                        ETA
                      </p>
                    </div>
                    <div className="p-3 text-center bg-gray-50 rounded-2xl">
                      <p className="text-base font-bold sm:text-lg text-emerald-500">
                        {effectiveRoute
                          ? Math.round(effectiveRoute.safetyScore)
                          : 91}
                      </p>
                      <p className="text-[11px] sm:text-xs text-gray-400 mt-0.5">
                        Safety
                      </p>
                    </div>
                  </div>

                  {plannedArrivalLabel && (
                    <div className="flex items-center justify-center gap-1.5 px-4 py-2.5 mb-4 bg-purple-50 rounded-xl">
                      <svg
                        viewBox="0 0 24 24"
                        className="flex-shrink-0 w-4 h-4 text-purple-600"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      >
                        <circle cx="12" cy="12" r="9" />
                        <path d="M12 7v5l3 3" />
                      </svg>
                      <p className="text-xs font-semibold text-purple-700 sm:text-sm">
                        Arrive by {plannedArrivalLabel}
                      </p>
                    </div>
                  )}

                  {(() => {
                    const liveHazards =
                      (activeRoute?.hazards as any[] | undefined) ?? [];
                    const hazardCount = liveHazards.length;

                    if (hazardCount === 0) {
                      return (
                        <div className="flex items-center gap-2 px-4 py-3 mb-4 border bg-emerald-50 rounded-xl border-emerald-100">
                          <svg
                            viewBox="0 0 24 24"
                            className="flex-shrink-0 w-4.5 h-4.5 sm:w-5 sm:h-5 text-emerald-500"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                          >
                            <path d="M20 6L9 17l-5-5" />
                          </svg>
                          <p className="text-xs font-medium sm:text-sm text-emerald-700">
                            No hazards reported on this route right now.
                          </p>
                        </div>
                      );
                    }

                    return (
                      <div className="flex items-center gap-2 px-4 py-3 mb-4 border bg-amber-50 rounded-xl border-amber-100">
                        <svg
                          viewBox="0 0 24 24"
                          className="flex-shrink-0 w-4.5 h-4.5 sm:w-5 sm:h-5 text-amber-500"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                        >
                          <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
                        </svg>
                        <p className="text-xs font-medium sm:text-sm text-amber-700">
                          {hazardCount} hazard{hazardCount === 1 ? "" : "s"}{" "}
                          reported on this route. Drive carefully.
                        </p>
                      </div>
                    );
                  })()}

                  {((activeRoute?.hazards as any[] | undefined)?.length ?? 0) >
                    0 && (
                    <div className="mb-4 space-y-3">
                      {(activeRoute!.hazards as any[]).map((hazard: any) => (
                        <div
                          key={hazard.id}
                          className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl"
                        >
                          <HazardListIcon type={hazard.type} />
                          <div className="flex-1 min-w-0">
                            <p className="text-xs font-semibold text-gray-900 truncate sm:text-sm">
                              {typeof hazard.title === "string"
                                ? hazard.title
                                : "Reported hazard"}
                            </p>
                            <p className="text-[11px] sm:text-xs text-gray-400">
                              {typeof hazard.location === "string"
                                ? hazard.location
                                : ""}
                            </p>
                          </div>
                          <span className="flex-shrink-0 px-2 py-1 text-[11px] sm:text-xs font-medium text-gray-500 bg-white rounded-lg">
                            {typeof hazard.distanceKm === "number"
                              ? `${hazard.distanceKm.toFixed(1)} km`
                              : hazard.distance}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </>
              )}
            </div>

            <div className="sticky bottom-0 z-10 flex-shrink-0 px-5 pt-3 pb-[calc(6rem+env(safe-area-inset-bottom))] bg-white border-t border-gray-100">
              <button
                onClick={handleStartTrip}
                disabled={planRouteMutation.isPending}
                className="w-full h-14 bg-purple-700 hover:bg-purple-800 disabled:bg-gray-300 disabled:cursor-not-allowed text-white font-semibold text-base rounded-2xl transition active:scale-[0.98] flex items-center justify-center gap-2 touch-manipulation"
              >
                Start trip
                <svg
                  viewBox="0 0 24 24"
                  className="w-5 h-5"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2.5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M5 12h14M12 5l7 7-7 7" />
                </svg>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ═══════════════════════════════════════════════════════
          SOS ACTIVE SCREEN
          ═══════════════════════════════════════════════════════ */}
      {showSOS && (
        <div className="fixed inset-0 z-[60] flex flex-col overflow-y-auto bg-red-500">
          <div className="flex items-start justify-between px-5 pt-14 sm:mx-auto sm:w-full sm:max-w-md">
            <div>
              <h2 className="text-2xl font-extrabold text-white sm:text-3xl">
                SOS Active
              </h2>
              <p className="mt-1 text-xs sm:text-sm text-white/80">
                SOS broadcast, nearby drivers and contacts notified
              </p>
            </div>
            <button
              onClick={() => setShowSOS(false)}
              className="flex items-center justify-center flex-shrink-0 w-8 h-8 text-white transition rounded-full sm:w-9 sm:h-9 bg-white/20 hover:bg-white/30"
            >
              <svg
                viewBox="0 0 24 24"
                className="w-4.5 h-4.5 sm:w-5 sm:h-5"
                fill="none"
                stroke="currentColor"
                strokeWidth="2.5"
                strokeLinecap="round"
              >
                <path d="M18 6L6 18M6 6l12 12" />
              </svg>
            </button>
          </div>

          {sosError && (
            <div className="mx-5 mt-3 rounded-xl bg-white/20 px-4 py-2.5 backdrop-blur-sm sm:mx-auto sm:w-full sm:max-w-md">
              <p className="text-[13px] font-medium text-white">
                Couldn&apos;t reach the server: {sosError}. Your emergency call
                still works.
              </p>
            </div>
          )}

          <div className="flex items-center justify-center flex-1">
            <div className="relative">
              <div className="absolute inset-0 w-40 h-40 -m-6 rounded-full sm:w-48 sm:h-48 bg-white/10 animate-ping" />
              <div className="absolute inset-0 w-32 h-32 -m-2 rounded-full sm:w-40 sm:h-40 bg-white/15" />
              <div className="relative flex items-center justify-center bg-white rounded-full shadow-2xl w-28 h-28 sm:w-36 sm:h-36">
                <svg
                  viewBox="0 0 24 24"
                  className="w-12 h-12 text-red-500 sm:w-16 sm:h-16"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="1.5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M12 3v1" />
                  <path d="M12 20v1" />
                  <path d="M4.2 7.2l.7.7" />
                  <path d="M19.1 16.1l.7.7" />
                  <path d="M3 12h1" />
                  <path d="M20 12h1" />
                  <path d="M4.2 16.8l.7-.7" />
                  <path d="M19.1 7.9l.7-.7" />
                  <path d="M12 8a4 4 0 0 1 4 4v3H8v-3a4 4 0 0 1 4-4z" />
                  <path d="M8 15v2a4 4 0 0 0 8 0v-2" />
                </svg>
              </div>
            </div>
          </div>

          <div className="px-5 pb-24 space-y-3 sm:mx-auto sm:w-full sm:max-w-md">
            <button
              onClick={() => {
                if (activeSosId) {
                  cancelSosMutation.mutate(activeSosId, {
                    onSettled: () => setActiveSosId(null),
                  });
                }
                setShowSOS(false);
                setSosError(null);
              }}
              disabled={cancelSosMutation.isPending}
              className="w-full h-12 sm:h-14 bg-white text-red-500 font-semibold text-sm sm:text-base rounded-xl hover:bg-gray-50 transition active:scale-[0.98] disabled:opacity-60"
            >
              {cancelSosMutation.isPending ? "Cancelling..." : "Cancel SOS"}
            </button>
            <a
              href="tel:112"
              className="w-full h-12 sm:h-14 bg-white/20 text-white font-semibold text-sm sm:text-base rounded-xl flex items-center justify-center gap-2 hover:bg-white/30 transition active:scale-[0.98]"
            >
              <svg
                viewBox="0 0 24 24"
                className="w-4.5 h-4.5 sm:w-5 sm:h-5"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z" />
              </svg>
              Call 112
            </a>
          </div>
        </div>
      )}

      {/* Auth flow for guests who tap the profile bar */}
      {showAuth && (
        <AuthFlow
          onClose={
            mustAuthenticateAsFleetOwner ? () => {} : () => setShowAuth(false)
          }
          onAuthSuccess={() => {
            setShowAuth(false);
            window.location.reload();
          }}
        />
      )}

      {/* Notifications panel */}
      {showNotifications && (
        <NotificationsPanel
          onClose={() => setShowNotifications(false)}
          notifications={notifications}
          isLoading={notificationsLoading}
          isMarkingAllRead={markAllRead.isPending}
          onMarkAllRead={() => markAllRead.mutate()}
          onNotificationClick={(n) => markNotificationRead.mutate(n.id)}
        />
      )}

      {/* BottomNav */}
      {!showPlanModal && !showScanResults && !showSOS && !isNavigating && (
        <div className="absolute bottom-0 left-0 right-0 z-[500] sm:flex sm:justify-center">
          <div className="w-full sm:max-w-md">
            <BottomNav />
          </div>
        </div>
      )}
    </div>
  );
}
