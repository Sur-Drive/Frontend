const API_BASE = "https://backend-production-01de.up.railway.app";

// ─── Interfaces ─────────────────────────────────────────────────────

export interface SendOtpPayload {
  identifier: string; // email or phone number
  role: string;
}

export interface SendOtpResponse {
  message: string;
  [key: string]: any;
}

// ─── Google Sign-In ─────────────────────────────────────────────────

export interface GoogleSignInPayload {
  idToken: string;
  role: string;
}

export interface GoogleSignInResponse {
  message: string;
  token?: string;
  tokens?: {
    accessToken: string;
    refreshToken: string;
  };
  user?: any;
  [key: string]: any;
}

// ─── Onboarding status ──────────────────────────────────────────────

export interface OnboardingStatusResponse {
  hasCompletedOnboarding: boolean;
  [key: string]: any;
}

export interface VerifyOtpPayload {
  identifier: string; // email or phone number
  otp: string;
}

export interface VerifyOtpResponse {
  message: string;
  token?: string;
  user?: any;
  [key: string]: any;
}

export interface PersonalInfoPayload {
  firstName: string;
  lastName: string;
  gender: string;
  dateOfBirth: string;
  occupation: string;
}

export interface PersonalInfoResponse {
  message: string;
  user?: any;
  [key: string]: any;
}

export interface SetPasswordPayload {
  password: string;
  confirmPassword: string;
}

export interface SetPasswordResponse {
  message: string;
  user?: any;
  [key: string]: any;
}

export interface LoginPayload {
  identifier: string; // email or phone number
  password: string;
}

export interface LoginResponse {
  message: string;
  token?: string;
  user?: any;
  [key: string]: any;
}

export interface RefreshTokenResponse {
  message: string;
  tokens?: {
    accessToken: string;
    refreshToken: string;
  };
  [key: string]: any;
}

export interface LogoutResponse {
  message: string;
  [key: string]: any;
}

// ─── Forgot Password interfaces ────────────────────────────────────

export interface ForgotPasswordPayload {
  identifier: string; // email or phone number
}

export interface ForgotPasswordResponse {
  message: string;
  sessionId?: string;
  [key: string]: any;
}

export interface VerifyResetOtpPayload {
  identifier: string; // email or phone number
  otp: string;
  sessionId: string; // session token returned by forgotPassword, required by backend
}

export interface VerifyResetOtpResponse {
  message: string;
  token?: string;
  [key: string]: any;
}

export interface SubscriptionInfo {
  plan: string;
  status: "active" | "inactive" | "expired" | "pending";
  paymentStatus: "paid" | "pending" | "failed" | "refunded";
  paymentReference: string;
  vehicleLimit: number;
  vehicleCount: number;
  startDate: string;
  endDate: string;
  isTrial: boolean;
  isExpired: boolean;
  daysRemaining: number;
}

export interface KYCStatusResponse {
  isKycCompleted: boolean;
  isVerified: boolean;
  status: "no_company" | "pending" | "active" | "suspended" | "expired";
  requiresKyc: boolean;
  subscription: SubscriptionInfo | null;
  companyId?: string;
}

export interface ResetPasswordPayload {
  password: string;
  confirmPassword: string;
  sessionId: string; // same session token used throughout the reset flow
}

export interface ResetPasswordResponse {
  message: string;
  [key: string]: any;
}

// ─── Update Password (Privacy screen — change password while logged in) ──

export interface UpdatePasswordPayload {
  password: string;
  confirmPassword: string;
}

export interface UpdatePasswordResponse {
  message: string;
  [key: string]: any;
}

// ─── Shared helpers ─────────────────────────────────────────────────

async function parseResponse(res: Response, fallbackMessage: string) {
  const responseText = await res.text();
  console.log("📥 Raw response:", responseText);
  console.log("📥 Status:", res.status);

  if (!res.ok) {
    let errorData: any = {};
    try {
      errorData = JSON.parse(responseText);
    } catch {
      errorData = { raw: responseText };
    }
    throw new Error(
      errorData.message ||
        errorData.error ||
        `${fallbackMessage} (${res.status})`,
    );
  }

  return responseText ? JSON.parse(responseText) : {};
}

function authHeaders(token: string | null): Record<string, string> {
  return token ? { Authorization: `Bearer ${token}` } : {};
}

function convertToISODate(dateString: string): string {
  if (!dateString.includes("/")) {
    return dateString;
  }

  const parts = dateString.split("/");
  if (parts.length !== 3) {
    throw new Error("Invalid date format. Expected DD/MM/YYYY or MM/DD/YYYY");
  }

  const [part1, part2, year] = parts;

  const day = parseInt(part1) > 12 ? part1 : part2;
  const month = parseInt(part1) > 12 ? part2 : part1;

  return `${year}-${month.padStart(2, "0")}-${day.padStart(2, "0")}`;
}

// ─── Auth functions ─────────────────────────────────────────────────

export async function sendOtp(
  payload: SendOtpPayload,
): Promise<SendOtpResponse> {
  console.log("📤 Sending OTP:", JSON.stringify(payload));

  const res = await fetch(`${API_BASE}/auth/send-otp`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
    },
    body: JSON.stringify(payload),
  });

  return parseResponse(res, "Failed to send OTP");
}

export async function getOnboardingStatus(): Promise<OnboardingStatusResponse> {
  const token = localStorage.getItem("token");

  console.log("📤 Checking onboarding status...");

  const res = await fetch(`${API_BASE}/auth/onboarding-status`, {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
      ...authHeaders(token),
    },
  });

  const data = await parseResponse(res, "Failed to get onboarding status");

  console.log("📥 Onboarding status:", data);

  return data;
}

export async function verifyOtp(
  payload: VerifyOtpPayload,
): Promise<VerifyOtpResponse> {
  console.log("📤 Verifying OTP:", JSON.stringify(payload));

  const res = await fetch(`${API_BASE}/auth/verify-otp`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
    },
    body: JSON.stringify(payload),
  });

  const data = await parseResponse(res, "Invalid OTP");

  const token =
    data.tokens?.accessToken || data.user?.accessToken || data.token;
  const refreshTokenValue = data.tokens?.refreshToken || data.refreshToken;

  if (token) {
    localStorage.setItem("token", token);
    console.log(
      "🔑 Token saved to localStorage:",
      token.substring(0, 30) + "...",
    );
  } else {
    console.warn("⚠️ No accessToken found in verify-otp response");
  }

  if (refreshTokenValue) {
    localStorage.setItem("refreshToken", refreshTokenValue);
    console.log("🔑 Refresh token saved");
  } else {
    console.warn("⚠️ No refreshToken found in verify-otp response");
  }

  return data;
}

export async function sendPersonalInfo(
  payload: PersonalInfoPayload,
): Promise<PersonalInfoResponse> {
  const token = localStorage.getItem("token");

  const formattedPayload = {
    ...payload,
    dateOfBirth: convertToISODate(payload.dateOfBirth),
  };

  console.log("📤 Sending personal info:", JSON.stringify(formattedPayload));

  const res = await fetch(`${API_BASE}/auth/personal-info`, {
    method: "PATCH",
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
      ...authHeaders(token),
    },
    body: JSON.stringify(formattedPayload),
  });

  return parseResponse(res, "Failed to save personal info");
}

export async function setPassword(
  payload: SetPasswordPayload,
): Promise<SetPasswordResponse> {
  const token = localStorage.getItem("token");

  console.log("📤 Setting password...");

  const res = await fetch(`${API_BASE}/auth/set-password`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
      ...authHeaders(token),
    },
    body: JSON.stringify(payload),
  });

  return parseResponse(res, "Failed to set password");
}

export async function login(payload: LoginPayload): Promise<LoginResponse> {
  const res = await fetch(`${API_BASE}/auth/login`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
    },
    body: JSON.stringify(payload),
  });

  const data = await parseResponse(res, "Login failed");

  const token =
    data.tokens?.accessToken || data.token || data.user?.accessToken;
  const refreshTokenValue = data.tokens?.refreshToken;

  if (token) {
    localStorage.setItem("token", token);
  } else {
    console.warn(
      "⚠️ No token found in login response. Keys:",
      Object.keys(data),
    );
  }

  if (refreshTokenValue) {
    localStorage.setItem("refreshToken", refreshTokenValue);
  }

  return data;
}

export async function googleSignIn(
  payload: GoogleSignInPayload,
): Promise<GoogleSignInResponse> {
  console.log("📤 Google Sign-In:", JSON.stringify(payload));

  const res = await fetch(`${API_BASE}/auth/google`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
    },
    body: JSON.stringify(payload),
  });

  const data = await parseResponse(res, "Google sign-in failed");

  // Save access token
  const token =
    data.tokens?.accessToken || data.token || data.user?.accessToken;

  if (token) {
    localStorage.setItem("token", token);
    console.log("🔑 Google access token saved");
  }

  // Save refresh token
  const refreshToken = data.tokens?.refreshToken || data.refreshToken;

  if (refreshToken) {
    localStorage.setItem("refreshToken", refreshToken);
  }

  return data;
}

export async function refreshToken(): Promise<RefreshTokenResponse> {
  const refreshTokenValue = localStorage.getItem("refreshToken");

  console.log("🔄 Refreshing token...");

  if (!refreshTokenValue) {
    throw new Error("No refresh token available");
  }

  const res = await fetch(`${API_BASE}/auth/refresh`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
    },
    body: JSON.stringify({ refreshToken: refreshTokenValue }),
  });

  const data = await parseResponse(res, "Token refresh failed");

  const newAccessToken =
    data.tokens?.accessToken || data.accessToken || data.token;
  const newRefreshToken = data.tokens?.refreshToken || data.refreshToken;

  if (newAccessToken) {
    localStorage.setItem("token", newAccessToken);
    console.log(
      "🔑 New access token saved:",
      newAccessToken.substring(0, 30) + "...",
    );
  } else {
    console.warn("⚠️ No access token in refresh response");
  }

  if (newRefreshToken) {
    localStorage.setItem("refreshToken", newRefreshToken);
  }

  return data;
}

export async function logout(): Promise<LogoutResponse> {
  const token = localStorage.getItem("token");
  const refreshTokenValue = localStorage.getItem("refreshToken");

  console.log("📤 Logging out...");

  try {
    const res = await fetch(`${API_BASE}/auth/logout`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
        ...authHeaders(token),
      },
      body: JSON.stringify({ refreshToken: refreshTokenValue }),
    });

    const data = await parseResponse(res, "Logout failed");
    return data;
  } finally {
    localStorage.removeItem("token");
    localStorage.removeItem("refreshToken");
    console.log("🔑 Local session cleared");
  }
}

export async function getKYCStatus(): Promise<KYCStatusResponse> {
  const token = localStorage.getItem("token");

  console.log("📤 Checking KYC status...");

  const res = await fetch(`${API_BASE}/fleet/kyc-status`, {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
      ...authHeaders(token),
    },
  });

  return parseResponse(res, "Failed to get KYC status");
}

// ─── Forgot Password functions ─────────────────────────────────────

export async function forgotPassword(
  payload: ForgotPasswordPayload,
): Promise<ForgotPasswordResponse> {
  console.log("📤 Sending forgot password:", JSON.stringify(payload));

  const res = await fetch(`${API_BASE}/auth/forgot-password`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
    },
    body: JSON.stringify(payload),
  });

  return parseResponse(res, "Failed to send reset code");
}

// export async function verifyResetOtp(
//   payload: VerifyResetOtpPayload,
// ): Promise<VerifyResetOtpResponse> {
//   console.log("📤 Verifying reset OTP:", JSON.stringify(payload));

//   const res = await fetch(`${API_BASE}/auth/verify-reset-otp`, {
//     method: "POST",
//     headers: {
//       "Content-Type": "application/json",
//       Accept: "application/json",
//       // Backend requires the session token from forgotPassword's
//       // response here — without it every request 401s with
//       // "Session token required", regardless of a correct OTP.
//       // The session token alone identifies the user server-side —
//       // sending an extra `identifier` field in the body (unlike the
//       // known-working Fleet reset flow, which sends only `{ otp }`)
//       // is what was causing "Invalid or expired session token".
//       Authorization: `Bearer ${payload.sessionId}`,
//     },
//     body: JSON.stringify({
//       otp: payload.otp,
//     }),
//   });

//   const data = await parseResponse(res, "Invalid OTP");

//   return data;
// }

export async function verifyResetOtp(
  payload: VerifyResetOtpPayload,
): Promise<VerifyResetOtpResponse> {
  const res = await fetch(`${API_BASE}/auth/verify-reset-otp`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
      Authorization: `Bearer ${payload.sessionId}`,
    },
    body: JSON.stringify({ otp: payload.otp }),
  });

  const data = await parseResponse(res, "Invalid OTP");

  if (data.token) {
    console.log("🔑 New reset token issued after OTP verification");
  } else {
    console.warn(
      "⚠️ No new token in verify-reset-otp response — falling back to original sessionId",
    );
  }

  return data; // caller should now prefer data.token over the original sessionId
}

export async function resetPassword(
  payload: ResetPasswordPayload,
): Promise<ResetPasswordResponse> {
  console.log("📤 Resetting password...");

  const res = await fetch(`${API_BASE}/auth/reset-password`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
      // Reuses the same session token from forgotPassword/verifyResetOtp —
      // the backend never issues a separate "reset token" after OTP
      // verification (verify-reset-otp's response has no such field), so
      // relying on one via localStorage always sent an empty Authorization
      // header here, producing "Session token required".
      Authorization: `Bearer ${payload.sessionId}`,
    },
    body: JSON.stringify({
      password: payload.password,
      confirmPassword: payload.confirmPassword,
    }),
  });

  return parseResponse(res, "Failed to reset password");
}

export async function updatePassword(
  payload: UpdatePasswordPayload,
): Promise<UpdatePasswordResponse> {
  const token = localStorage.getItem("token");

  console.log("📤 Updating password...", payload); // log the actual payload while debugging

  const res = await fetch(`${API_BASE}/auth/set-password`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
      ...authHeaders(token),
    },
    body: JSON.stringify(payload),
  });

  return parseResponse(res, "Failed to update password");
}
